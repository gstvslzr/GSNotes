// MyGSNotes+ desktop shell (Electron main process)
const { app, BrowserWindow, protocol, net, shell, globalShortcut, ipcMain, Menu, session, nativeImage, dialog, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const zlib = require('zlib');
const { execFile } = require('child_process');
const http = require('http');
const crypto = require('crypto');
const { pathToFileURL } = require('url');

const APP_DIR = path.join(__dirname, 'app');
const APP_NAME = 'MyGSNotes+';
const APP_VERSION = '26.10.03';
// Plain startup log on the terminal, so "the window never appeared" can be diagnosed.
const log = (...a) => { try { console.log('[MyGSNotes+]', ...a); } catch {} };
// Safe mode: no graphics acceleration. For graphics drivers that keep the window from drawing.
const SAFE_MODE = process.argv.includes('--safe-mode') || process.env.MYGSNOTES_SAFE_MODE === '1';
if (SAFE_MODE) {
  app.disableHardwareAcceleration();
  // the /usr/bin/mygsnotes-plus launcher also adds --ozone-platform=x11 (XWayland) in safe mode
}
const APP_COPYRIGHT = '© 2026 Gustavo Salazar';
app.setName(APP_NAME);

// Profile folder: ~/.config/MyGSNotesPlus. Notes from the earlier "GSNotes" app are carried over on first start.
(function migrateProfile() {
  const base = app.getPath('appData');
  const target = path.join(base, 'MyGSNotesPlus'); const old = path.join(base, 'GSNotes');
  try { if (!fs.existsSync(target) && fs.existsSync(old)) fs.cpSync(old, target, { recursive: true, filter: (src) => !/Singleton(Lock|Socket|Cookie)$/.test(src) }); } catch (e) { console.warn('MyGSNotes+: could not copy the old profile:', e.message); }
  app.setPath('userData', target);
})();
const SCHEME = 'app';
const ORIGIN = `${SCHEME}://gsnotes`;
const CAPTURE_HOTKEY = 'CommandOrControl+Alt+N';

// app://gsnotes behaves like a normal https origin: secure context (Web Crypto),
// persistent IndexedDB, fetch support.
protocol.registerSchemesAsPrivileged([
  { scheme: SCHEME, privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } },
]);

let win = null;
const pendingCommands = [];

function sendCommand(cmd) {
  if (!win) { pendingCommands.push(cmd); return; }
  if (win.isMinimized()) win.restore();
  win.show(); win.focus();
  if (win.webContents.isLoading()) pendingCommands.push(cmd);
  else win.webContents.send('gs:command', cmd);
}
function commandFromArgs(argv) {
  if (argv.includes('--capture')) return 'capture';
  if (argv.includes('--today')) return 'today';
  if (argv.includes('--help-page')) return 'help';
  return null;
}

// ---- window state
const stateFile = () => path.join(app.getPath('userData'), 'window-state.json');
function loadState() { try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch { return { width: 1280, height: 820 }; } }
function saveState() {
  if (!win || win.isDestroyed()) return;
  try { fs.writeFileSync(stateFile(), JSON.stringify({ ...win.getNormalBounds(), maximized: win.isMaximized() })); } catch {}
}

function createWindow() {
  const st = loadState();
  win = new BrowserWindow({
    x: st.x, y: st.y, width: st.width || 1280, height: st.height || 820, minWidth: 380, minHeight: 480,
    title: 'MyGSNotes+', backgroundColor: '#eef1f5', autoHideMenuBar: false, show: false,
    icon: nativeImage.createFromPath(path.join(__dirname, 'icon.png')),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: true },
  });
  if (st.maximized) win.maximize();
  log('window created');
  win.once('ready-to-show', () => { log('page drawn, showing window'); win.show(); });
  // never stay invisible: show the window even if the page has not reported that it finished drawing
  setTimeout(() => { if (win && !win.isVisible()) { log('page has not finished drawing after 5 s; showing the window anyway. If it stays blank, start with: mygsnotes-plus --safe-mode'); win.show(); } }, 5000);
  win.webContents.on('did-fail-load', (_e, code, desc, url) => { log('page failed to load:', code, desc, url); if (win && !win.isVisible()) win.show(); });
  win.webContents.on('render-process-gone', (_e, d) => {
    log('page process stopped:', d.reason, 'exit code', d.exitCode);
    if (!win) return; win.show();
    dialog.showMessageBox(win, { type: 'error', title: APP_NAME, message: 'MyGSNotes+ stopped drawing its window.', detail: `Reason: ${d.reason}. Your notes are safe.\n\nIf this happens again, start MyGSNotes+ in safe mode: right-click its icon and choose "Safe mode", or run: mygsnotes-plus --safe-mode`, buttons: ['Reload', 'Quit'] })
      .then(({ response }) => { if (response === 0 && win) win.reload(); else app.quit(); });
  });
  win.webContents.on('did-finish-load', () => log('page loaded'));
  win.loadURL(`${ORIGIN}/index.html`);
  win.webContents.on('did-finish-load', () => { while (pendingCommands.length) win.webContents.send('gs:command', pendingCommands.shift()); });

  // links open in the system browser; the app never navigates away from itself
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^(https?|mailto):/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith(ORIGIN)) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });

  // spelling suggestions on right-click in the editor
  win.webContents.on('context-menu', (_e, p) => {
    const items = [];
    for (const s of p.dictionarySuggestions.slice(0, 5)) items.push({ label: s, click: () => win.webContents.replaceMisspelling(s) });
    if (p.misspelledWord) items.push({ label: 'Add to dictionary', click: () => win.webContents.session.addWordToSpellCheckerDictionary(p.misspelledWord) }, { type: 'separator' });
    if (p.isEditable) items.push({ role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' });
    else if (p.selectionText) items.push({ role: 'copy' });
    if (items.length) Menu.buildFromTemplate(items).popup();
  });

  for (const ev of ['resize', 'move', 'close']) win.on(ev, saveState);
  win.on('closed', () => { win = null; });
}

// ---- single instance: a second launch focuses the first (and passes --capture / --today)
log(`starting ${APP_VERSION} (Electron ${process.versions.electron}, ${process.env.XDG_SESSION_TYPE || 'unknown'} session${SAFE_MODE ? ', safe mode' : ''})`);
process.on('uncaughtException', (e) => { log('error:', e && e.stack || e); });
app.on('child-process-gone', (_e, d) => log(`${d.type} process stopped: ${d.reason} (exit code ${d.exitCode})`));
// A settings folder owned by another user (for example after running the app with sudo) makes Chromium
// believe another copy is running, and the app would quit without a window. Say so plainly instead.
(function checkProfileWritable() {
  const dir = app.getPath('userData');
  try { if (fs.existsSync(dir)) fs.accessSync(dir, fs.constants.R_OK | fs.constants.W_OK | fs.constants.X_OK); return; }
  catch {}
  const who = os.userInfo().username;
  const msg = `MyGSNotes+ cannot open its settings folder:\n${dir}\n\nIt belongs to another user, usually because MyGSNotes+ was once started with sudo. Your notes are still there.\n\nTo fix it, open a terminal and run:\nsudo chown -R ${who}:${who} "${dir}"\n\nThen start MyGSNotes+ again.`;
  log(msg.replace(/\n+/g, ' '));
  app.whenReady().then(() => { dialog.showErrorBox('MyGSNotes+ cannot start', msg); app.exit(1); });
  app.__profileBlocked = true;
})();
if (app.__profileBlocked) { /* waiting for the message above */ }
else if (!app.requestSingleInstanceLock()) { log('MyGSNotes+ is already running; asking that copy to show its window. If no window appears, run: pkill -f mygsnotes-plus  and start it again.'); app.quit(); }
else {
  app.on('second-instance', (_e, argv) => { const c = commandFromArgs(argv); if (c) sendCommand(c); else if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } else if (app.isReady()) createWindow(); });

  app.whenReady().then(() => {
    log('ready, user data in', app.getPath('userData'));
    // serve the bundled app from app://gsnotes/...
    protocol.handle(SCHEME, (req) => {
      const { pathname } = new URL(req.url);
      const file = path.normalize(path.join(APP_DIR, decodeURIComponent(pathname)));
      if (!file.startsWith(APP_DIR)) return new Response('Not found', { status: 404 });
      return net.fetch(pathToFileURL(file).toString());
    });

    // allow what a notes app needs; refuse camera, location, etc.
    const allowed = new Set(['notifications', 'clipboard-sanitized-write', 'fileSystem', 'fullscreen']);
    session.defaultSession.setPermissionRequestHandler((_wc, perm, cb) => cb(allowed.has(perm)));
    session.defaultSession.setPermissionCheckHandler((_wc, perm) => allowed.has(perm));

    // HTTP for AI providers and WebDAV, done here so browser CORS rules don't block local servers
    ipcMain.handle('gs:http', async (_e, req) => {
      try {
        const u = new URL(req.url);
        if (!/^https?:$/.test(u.protocol)) return { error: 'Only http and https are allowed' };
        const res = await net.fetch(u.toString(), { method: req.method || 'GET', headers: req.headers || {}, body: req.body ?? undefined, cache: 'no-store' });
        return { status: res.status, body: await res.text() };
      } catch (err) { return { error: String(err && err.message || err) }; }
    });
    ipcMain.handle('gs:version', () => app.getVersion());
    ipcMain.handle('gs:info', () => ({ version: APP_VERSION, electron: process.versions.electron, chrome: process.versions.chrome, node: process.versions.node, platform: `${process.platform} ${process.arch}`, dataDir: app.getPath('userData'), licenceFile: '/usr/share/doc/mygsnotes-plus/copyright', session: process.env.XDG_SESSION_TYPE || '' }));
    ipcMain.handle('gs:open-data', () => shell.openPath(app.getPath('userData')));
    ipcMain.handle('gs:pick-folder', async (_e, current) => {
      const r = await dialog.showOpenDialog(win, { title: 'Choose a folder for MyGSNotes+ backups', defaultPath: current || path.join(app.getPath('documents'), 'MyGSNotes+ Backups'), properties: ['openDirectory', 'createDirectory'] });
      return r.canceled ? null : r.filePaths[0];
    });
    ipcMain.handle('gs:backup-write', async (_e, { dir, name, data, keep }) => {
      try {
        if (!dir || !/^gsnotes-backup-[\w-]+\.json$/.test(name)) return { error: 'Invalid backup request' };
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(path.join(dir, name), String(data));
        const old = fs.readdirSync(dir).filter((f) => /^gsnotes-backup-.*\.json$/.test(f)).sort().reverse();
        for (const f of old.slice(Math.max(1, +keep || 10))) fs.unlinkSync(path.join(dir, f));
        return { ok: true };
      } catch (err) { return { error: String(err.message || err) }; }
    });
    ipcMain.handle('gs:onenote', async (_e, paths) => importOneNote(paths));
    ipcMain.handle('cal:info', () => ({ secureStorage: safeStorage.isEncryptionAvailable() && (typeof safeStorage.getSelectedStorageBackend !== 'function' || safeStorage.getSelectedStorageBackend() !== 'basic_text'), bases: CAL_MOCK ? { google: CAL_MOCK + '/google/calendar/v3', graph: CAL_MOCK + '/graph/v1.0' } : null }));
    ipcMain.handle('cal:oauth', async (_e, req) => { try { return await calOAuth(req); } catch (err) { return { error: String(err.message || err) }; } });
    ipcMain.handle('cal:basic', (_e, { accountId, username, password }) => { const creds = loadCreds(); const id = accountId || 'acct-' + crypto.randomBytes(6).toString('hex'); creds[id] = { type: 'basic', username: String(username), password: String(password) }; saveCreds(creds); return { accountId: id }; });
    ipcMain.handle('cal:request', async (_e, req) => { try { return await calRequest(req); } catch (err) { return { error: String(err.message || err) }; } });
    ipcMain.handle('cal:forget', (_e, accountId) => { const creds = loadCreds(); delete creds[accountId]; saveCreds(creds); return true; });

    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { label: 'File', submenu: [
        { label: 'Quick capture', accelerator: CAPTURE_HOTKEY, click: () => sendCommand('capture') },
        { label: 'Today’s note', click: () => sendCommand('today') },
        { label: 'Command palette', accelerator: 'CommandOrControl+K', registerAccelerator: false, click: () => sendCommand('palette') },
        { type: 'separator' }, { role: 'quit' }] },
      { role: 'editMenu' },
      { label: 'View', submenu: [{ role: 'reload' }, { role: 'toggleDevTools' }, { type: 'separator' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }] },
      { label: 'Help', submenu: [
        { label: 'MyGSNotes+ Help', accelerator: 'F1', registerAccelerator: false, click: () => sendCommand('help') },
        { label: 'Keyboard shortcuts', click: () => sendCommand('help:keys') },
        { label: 'Troubleshooting', click: () => sendCommand('help:trouble') },
        { type: 'separator' },
        { label: 'Open data folder', click: () => shell.openPath(app.getPath('userData')) },
        { label: 'Third-party licences', click: () => sendCommand('about:licences') },
        { type: 'separator' },
        { label: 'About MyGSNotes+', click: () => sendCommand('about') }] },
    ]));

    createWindow();
    const first = commandFromArgs(process.argv); if (first) pendingCommands.push(first);

    // system-wide quick capture (works on X11; on some Wayland desktops global hotkeys are refused)
    if (!globalShortcut.register(CAPTURE_HOTKEY, () => sendCommand('capture'))) console.warn('MyGSNotes+: could not register', CAPTURE_HOTKEY);
  });

  app.on('will-quit', () => globalShortcut.unregisterAll());
  app.on('window-all-closed', () => app.quit());
  app.on('activate', () => { if (!win) createWindow(); });
}

// ---------------- OneNote import ----------------
// Converts OneNote files to HTML with the bundled converter (built from Joplin's MPL-2.0 onenote-converter),
// then hands the pages (HTML + their attachments as data URLs) to the page for conversion to Markdown.
function converterPath() {
  const name = process.platform === 'win32' ? 'gsnotes-onenote.exe' : 'gsnotes-onenote';
  return app.isPackaged ? path.join(process.resourcesPath, name) : path.join(__dirname, 'bin', name);
}
function unzipTo(zipFile, dest) {
  const buf = fs.readFileSync(zipFile);
  let eocd = buf.length - 22; while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  if (eocd < 0) throw new Error('That .zip file is damaged or not a zip.');
  const count = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('Unsupported zip layout.');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), lho = buf.readUInt32LE(p + 42);
    const flags = buf.readUInt16LE(p + 8);
    const name = buf.slice(p + 46, p + 46 + nlen).toString(flags & 0x800 ? 'utf8' : 'latin1').replace(/\\/g, '/');
    p += 46 + nlen + xlen + clen;
    if (name.endsWith('/')) continue;
    const out = path.normalize(path.join(dest, name));
    if (!out.startsWith(dest)) continue; // never write outside the temp folder
    const ds = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
    const raw = buf.slice(ds, ds + csize);
    const data = method === 0 ? raw : method === 8 ? zlib.inflateRawSync(raw) : null;
    if (!data) continue;
    fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, data);
  }
}
function walk(dir) { const out = []; for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) out.push(...walk(p)); else out.push(p); } return out; }
function runConverter(input, outDir, baseDir) {
  return new Promise((resolve) => {
    execFile(converterPath(), [input, outDir, baseDir], { maxBuffer: 64 * 1024 * 1024, timeout: 10 * 60 * 1000 }, (err, _stdout, stderr) => {
      const warnings = String(stderr || '').split('\n').filter((l) => /^Warning:/.test(l)).length;
      resolve({ ok: !err, error: err ? (String(stderr || '').split('\n').find((l) => /^Error/.test(l)) || err.message) : null, warnings });
    });
  });
}
async function importOneNote(paths) {
  try {
    if (!fs.existsSync(converterPath())) return { error: 'The OneNote converter is missing from this installation.' };
    if (!paths || !paths.length) {
      const r = await dialog.showOpenDialog(win, { title: 'Import from OneNote', properties: ['openFile', 'multiSelections'], filters: [{ name: 'OneNote', extensions: ['onepkg', 'one', 'zip'] }] });
      if (r.canceled) return { cancelled: true };
      paths = r.filePaths;
    }
    paths = paths.filter((p) => /\.(onepkg|one|zip)$/i.test(p) && fs.existsSync(p));
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gsnotes-onenote-'));
    const work = path.join(tmp, 'in'), out = path.join(tmp, 'out'); fs.mkdirSync(work); fs.mkdirSync(out);
    const warnings = []; let warnCount = 0;
    try {
      for (const src of paths) {
        const stem = path.basename(src).replace(/\.[^.]+$/, '');
        const dir = path.join(work, stem); fs.mkdirSync(dir, { recursive: true });
        if (/\.zip$/i.test(src)) unzipTo(src, dir); else fs.copyFileSync(src, path.join(dir, path.basename(src)));
        const inputs = walk(dir).filter((f) => /\.(one|onepkg)$/i.test(f) && !/OneNote_RecycleBin/i.test(f));
        if (!inputs.length) warnings.push(`${path.basename(src)}: no OneNote sections found`);
        for (const f of inputs) {
          const target = path.join(out, path.relative(work, path.dirname(f)));
          fs.mkdirSync(target, { recursive: true });
          const r = await runConverter(f, target, path.dirname(f) + path.sep);
          warnCount += r.warnings;
          if (!r.ok) warnings.push(`${path.basename(f)}: ${r.error}`);
        }
      }
      const pages = [];
      const htmls = walk(out).filter((f) => /\.html$/i.test(f));
      for (const h of htmls) {
        if (fs.existsSync(h.replace(/\.html$/i, '')) && fs.statSync(h.replace(/\.html$/i, '')).isDirectory()) continue; // section / notebook index pages
        const dir = path.dirname(h); const files = {};
        const html = fs.readFileSync(h, 'utf8');
        for (const f of fs.readdirSync(dir)) {
          const p = path.join(dir, f); if (!fs.statSync(p).isFile() || /\.html$/i.test(f)) continue;
          if (!html.includes(f) && !html.includes(encodeURIComponent(f)) && !html.includes(encodeURI(f))) continue;
          const ext = (f.split('.').pop() || '').toLowerCase();
          const mime = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', bmp: 'image/bmp', pdf: 'application/pdf' }[ext] || 'application/octet-stream';
          files[f] = `data:${mime};base64,` + fs.readFileSync(p).toString('base64');
        }
        const rel = path.relative(out, dir).split(path.sep).filter(Boolean);
        pages.push({ path: rel, name: path.basename(h, '.html'), html, files });
      }
      if (warnCount) warnings.push(`${warnCount} formatting detail${warnCount === 1 ? '' : 's'} could not be converted`);
      return { pages, warnings };
    } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
  } catch (err) { return { error: String(err.message || err) }; }
}

// ---------------- Calendar accounts ----------------
// Credentials (OAuth refresh tokens, CalDAV passwords) stay in the main process, encrypted with the
// operating system's keyring through Electron safeStorage. The page only ever sees an account id.
const CAL_MOCK = process.env.GSNOTES_CAL_MOCK || ''; // test servers only
const OAUTH = {
  google: { auth: 'https://accounts.google.com/o/oauth2/v2/auth', token: 'https://oauth2.googleapis.com/token', scope: 'openid email https://www.googleapis.com/auth/calendar', host: '127.0.0.1' },
  microsoft: { auth: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize', token: 'https://login.microsoftonline.com/common/oauth2/v2.0/token', scope: 'offline_access User.Read Calendars.ReadWrite', host: 'localhost' },
};
if (CAL_MOCK) { OAUTH.google.auth = CAL_MOCK + '/google/auth'; OAUTH.google.token = CAL_MOCK + '/google/token'; OAUTH.microsoft.auth = CAL_MOCK + '/ms/authorize'; OAUTH.microsoft.token = CAL_MOCK + '/ms/token'; }
const credPath = () => path.join(app.getPath('userData'), 'calendar-credentials.bin');
function loadCreds() {
  try {
    const buf = fs.readFileSync(credPath());
    if (buf.slice(0, 5).toString() === 'PLAIN') return JSON.parse(buf.slice(5).toString());
    return JSON.parse(safeStorage.decryptString(buf));
  } catch { return {}; }
}
function saveCreds(c) {
  const json = JSON.stringify(c);
  const data = safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(json) : Buffer.concat([Buffer.from('PLAIN'), Buffer.from(json)]);
  fs.writeFileSync(credPath(), data, { mode: 0o600 });
}
const b64url = (b) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
async function postForm(url, params) {
  const res = await net.fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(params).toString() });
  const body = await res.text(); let j = {}; try { j = JSON.parse(body); } catch {}
  if (!res.ok) throw new Error(j.error_description || j.error || `Sign-in server returned ${res.status}`);
  return j;
}
function waitForCode(host, state) {
  return new Promise((resolve, reject) => {
    const servers = []; let done = false;
    const finish = (err, val) => { if (done) return; done = true; servers.forEach((s) => s.close()); clearTimeout(timer); err ? reject(err) : resolve(val); };
    const handler = (req, res) => {
      const u = new URL(req.url, 'http://localhost');
      if (!u.searchParams.has('code') && !u.searchParams.has('error')) { res.writeHead(404); return res.end(); }
      const ok = u.searchParams.get('state') === state && u.searchParams.get('code');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(`<!doctype html><meta charset="utf-8"><title>MyGSNotes+</title><body style="font:16px system-ui;padding:40px;text-align:center"><h2>${ok ? 'MyGSNotes+ is connected' : 'Sign-in did not finish'}</h2><p>${ok ? 'You can close this tab and return to MyGSNotes+.' : 'Return to MyGSNotes+ and try again.'}</p></body>`);
      if (ok) finish(null, u.searchParams.get('code')); else finish(new Error(u.searchParams.get('error_description') || u.searchParams.get('error') || 'Sign-in was cancelled.'));
    };
    const s4 = http.createServer(handler); servers.push(s4);
    const timer = setTimeout(() => finish(new Error('Sign-in timed out after 5 minutes.')), 5 * 60 * 1000);
    s4.on('error', (e) => finish(e));
    s4.listen(0, '127.0.0.1', () => {
      const port = s4.address().port;
      if (host === 'localhost') { const s6 = http.createServer(handler); s6.on('error', () => {}); s6.listen(port, '::1'); servers.push(s6); }
      resolve.port = port; waitForCode.onPort && waitForCode.onPort(port);
    });
    waitForCode.server = s4;
  });
}
async function calOAuth({ provider, clientId, clientSecret }) {
  const cfg = OAUTH[provider]; if (!cfg) throw new Error('Unknown provider');
  if (!clientId) throw new Error('Enter the Client ID first.');
  const verifier = b64url(crypto.randomBytes(32)); const challenge = b64url(crypto.createHash('sha256').update(verifier).digest()); const state = b64url(crypto.randomBytes(16));
  let port; const portReady = new Promise((r) => { waitForCode.onPort = (p) => { port = p; r(); }; });
  const codeP = waitForCode(cfg.host, state);
  await portReady;
  const redirect = `http://${cfg.host}:${port}`;
  const q = { client_id: clientId, redirect_uri: redirect, response_type: 'code', scope: cfg.scope, state, code_challenge: challenge, code_challenge_method: 'S256' };
  if (provider === 'google') Object.assign(q, { access_type: 'offline', prompt: 'consent' }); else q.prompt = 'select_account';
  const authUrl = cfg.auth + '?' + new URLSearchParams(q).toString();
  if (CAL_MOCK) net.fetch(authUrl).catch(() => {}); else shell.openExternal(authUrl);
  const code = await codeP;
  const params = { client_id: clientId, code, redirect_uri: redirect, grant_type: 'authorization_code', code_verifier: verifier };
  if (provider === 'google' && clientSecret) params.client_secret = clientSecret;
  if (provider === 'microsoft') params.scope = cfg.scope;
  const tok = await postForm(cfg.token, params);
  if (!tok.refresh_token) throw new Error('The sign-in did not grant offline access. Remove MyGSNotes+ from your account’s connected apps and try again.');
  let email = '';
  if (tok.id_token) { try { email = JSON.parse(Buffer.from(tok.id_token.split('.')[1], 'base64').toString()).email || ''; } catch {} }
  if (provider === 'microsoft') { try { const me = await (await net.fetch((CAL_MOCK ? CAL_MOCK + '/graph/v1.0' : 'https://graph.microsoft.com/v1.0') + '/me', { headers: { Authorization: 'Bearer ' + tok.access_token } })).json(); email = me.mail || me.userPrincipalName || ''; } catch {} }
  const accountId = 'acct-' + crypto.randomBytes(6).toString('hex');
  const creds = loadCreds();
  creds[accountId] = { type: 'oauth', provider, clientId, clientSecret: clientSecret || '', refresh_token: tok.refresh_token, access_token: tok.access_token, expires_at: Date.now() + (tok.expires_in || 3600) * 1000 };
  saveCreds(creds);
  return { accountId, email };
}
async function accessToken(accountId, force) {
  const creds = loadCreds(); const c = creds[accountId]; if (!c) throw new Error('This calendar account is not connected on this computer. Remove it and add it again.');
  if (!force && c.access_token && c.expires_at - 60000 > Date.now()) return c.access_token;
  const cfg = OAUTH[c.provider];
  const params = { client_id: c.clientId, refresh_token: c.refresh_token, grant_type: 'refresh_token' };
  if (c.provider === 'google' && c.clientSecret) params.client_secret = c.clientSecret;
  if (c.provider === 'microsoft') params.scope = cfg.scope;
  const tok = await postForm(cfg.token, params);
  c.access_token = tok.access_token; c.expires_at = Date.now() + (tok.expires_in || 3600) * 1000; if (tok.refresh_token) c.refresh_token = tok.refresh_token;
  saveCreds(creds); return c.access_token;
}
async function calRequest({ accountId, url, method = 'GET', headers = {}, body = null }) {
  const u = new URL(url); if (!/^https?:$/.test(u.protocol)) throw new Error('Only http and https links are supported.');
  const creds = loadCreds(); const c = accountId ? creds[accountId] : null;
  const send = async (force) => {
    const h = { ...headers };
    if (c && c.type === 'oauth') h.Authorization = 'Bearer ' + await accessToken(accountId, force);
    if (c && c.type === 'basic') h.Authorization = 'Basic ' + Buffer.from(`${c.username}:${c.password}`).toString('base64');
    const res = await net.fetch(u.toString(), { method, headers: h, body: body ?? undefined, cache: 'no-store', redirect: 'follow' });
    const out = { status: res.status, body: await res.text(), headers: {} };
    for (const k of ['etag', 'location', 'content-type']) { const v = res.headers.get(k); if (v) out.headers[k] = v; }
    return out;
  };
  let r = await send(false);
  if (r.status === 401 && c && c.type === 'oauth') r = await send(true);
  return r;
}
