// Narrow bridge between the GSNotes page and the desktop shell.
const { contextBridge, ipcRenderer } = require('electron');

let version = '';
ipcRenderer.invoke('gs:version').then((v) => { version = v; });

// Commands from the menu or launcher can arrive before the page has finished starting; hold them until it listens.
const queued = []; let handler = null;
ipcRenderer.on('gs:command', (_e, cmd) => { if (handler) handler(String(cmd)); else queued.push(String(cmd)); });

contextBridge.exposeInMainWorld('gsDesktop', {
  get version() { return version; },
  http: (req) => ipcRenderer.invoke('gs:http', {
    url: String(req.url), method: String(req.method || 'GET'),
    headers: Object.fromEntries(Object.entries(req.headers || {}).map(([k, v]) => [String(k), String(v)])),
    body: req.body == null ? null : String(req.body),
  }),
  pickFolder: (current) => ipcRenderer.invoke('gs:pick-folder', current ? String(current) : ''),
  backupWrite: (req) => ipcRenderer.invoke('gs:backup-write', { dir: String(req.dir || ''), name: String(req.name), data: String(req.data), keep: Number(req.keep) || 10 }),
  oneNote: (paths) => ipcRenderer.invoke('gs:onenote', Array.isArray(paths) ? paths.map(String) : null),
  appInfo: () => ipcRenderer.invoke('gs:info'),
  openDataFolder: () => ipcRenderer.invoke('gs:open-data'),
  calInfo: () => ipcRenderer.invoke('cal:info'),
  calOAuth: (req) => ipcRenderer.invoke('cal:oauth', { provider: String(req.provider), clientId: String(req.clientId || ''), clientSecret: String(req.clientSecret || '') }),
  calBasic: (req) => ipcRenderer.invoke('cal:basic', { accountId: req.accountId ? String(req.accountId) : '', username: String(req.username || ''), password: String(req.password || '') }),
  calRequest: (req) => ipcRenderer.invoke('cal:request', { accountId: req.accountId ? String(req.accountId) : '', url: String(req.url), method: String(req.method || 'GET'), headers: Object.fromEntries(Object.entries(req.headers || {}).map(([k, v]) => [String(k), String(v)])), body: req.body == null ? null : String(req.body) }),
  calForget: (id) => ipcRenderer.invoke('cal:forget', String(id)),
  onCommand: (fn) => { handler = fn; while (queued.length) fn(queued.shift()); },
});
