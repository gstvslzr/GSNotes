#!/usr/bin/env bash
# Build mygsnotes-plus_<version>_amd64.deb (MyGSNotes+, © 2026 Gustavo Salazar) from the web source.
# Needs: python3 + Pillow, node/npm (npm install once), dpkg-deb.
set -euo pipefail
cd "$(dirname "$0")"

VERSION=26.10.03
ARCH=amd64
PKG=mygsnotes-plus
STAGE=deb/stage
OUT=deb/${PKG}_${VERSION}_${ARCH}.deb

python3 build_desktop.py
npx @electron/packager . MyGSNotes+ --platform=linux --arch=x64 --electron-version=44.5.1 \
  --out=out --overwrite --asar --icon=icon.png --executable-name=mygsnotes-plus \
  --ignore='^/out' --ignore='^/deb' --ignore='^/node_modules' --ignore='^/build_' --ignore='\.sh$' --ignore='^/bin' --ignore='^/onenote-cli' \
  --extra-resource=bin/gsnotes-onenote

rm -rf deb && mkdir -p "$STAGE"/{DEBIAN,opt,usr/bin,usr/share/applications,usr/share/doc/$PKG}
cp -a "out/MyGSNotes+-linux-x64" "$STAGE/opt/MyGSNotesPlus"
# the packager creates its output folder as 0700; everyone must be able to read and run the app
chmod -R u+rwX,go+rX,go-w "$STAGE/opt/MyGSNotesPlus"
chmod 4755 "$STAGE/opt/MyGSNotesPlus/chrome-sandbox"   # setuid sandbox helper (owned by root in the package)
cat > "$STAGE/usr/bin/mygsnotes-plus" <<'LAUNCHER'
#!/bin/sh
# MyGSNotes+ launcher. Safe mode also uses X11 (XWayland) when available, which avoids Wayland display problems.
for a in "$@"; do
  if [ "$a" = "--safe-mode" ] && [ -n "${DISPLAY:-}" ]; then set -- "$@" --ozone-platform=x11; break; fi
done
exec /opt/MyGSNotesPlus/mygsnotes-plus "$@"
LAUNCHER
chmod 755 "$STAGE/usr/bin/mygsnotes-plus"

# icons for menus and docks
for s in 48 64 128 256 512; do
  mkdir -p "$STAGE/usr/share/icons/hicolor/${s}x${s}/apps"
  python3 -c "from PIL import Image; Image.open('icon.png').resize(($s,$s), Image.LANCZOS).save('$STAGE/usr/share/icons/hicolor/${s}x${s}/apps/mygsnotes-plus.png')"
done

cat > "$STAGE/usr/share/applications/mygsnotes-plus.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=MyGSNotes+
GenericName=Notes
Comment=Private, offline-first Markdown notes — © 2026 Gustavo Salazar
Exec=/opt/MyGSNotesPlus/mygsnotes-plus %U
Icon=mygsnotes-plus
Terminal=false
Categories=Office;Utility;TextEditor;
Keywords=notes;markdown;journal;todo;flashcards;
StartupWMClass=MyGSNotes+
Actions=capture;today;safemode;

[Desktop Action capture]
Name=Quick capture
Exec=/opt/MyGSNotesPlus/mygsnotes-plus --capture

[Desktop Action today]
Name=Today's note
Exec=/opt/MyGSNotesPlus/mygsnotes-plus --today

[Desktop Action safemode]
Name=Safe mode (no graphics acceleration)
Exec=/usr/bin/mygsnotes-plus --safe-mode
EOF

# Ubuntu 23.10+ restricts unprivileged user namespaces; Chromium-based apps need this AppArmor profile.
cat > "$STAGE/opt/MyGSNotesPlus/apparmor-profile" <<'EOF'
abi <abi/4.0>,
include <tunables/global>

profile mygsnotes-plus /opt/MyGSNotesPlus/mygsnotes-plus flags=(unconfined) {
  userns,
  include if exists <local/mygsnotes-plus>
}
EOF

cat > "$STAGE/usr/share/doc/$PKG/copyright" <<EOF
MyGSNotes+ ${VERSION}
Copyright © 2026 Gustavo Salazar. All rights reserved.
By Gustavo Salazar <gus.salazar66@gmail.com>
Bundled third-party software keeps its own license:
 Electron and Chromium (MIT/BSD; see /opt/MyGSNotesPlus/LICENSE and LICENSES.chromium.html),
 marked (MIT), DOMPurify (Apache-2.0 or MPL-2.0), pdf.js (Apache-2.0),
 Tesseract.js and tesseract.js-core (Apache-2.0), Tesseract language data (Apache-2.0),
 mammoth (BSD-2-Clause), ical.js (MPL-2.0), gsnotes-onenote built from Joplin's onenote-converter
 (MPL-2.0; source: https://github.com/laurent22/joplin/tree/dev/packages/onenote-converter),
 Atkinson Hyperlegible, Bricolage Grotesque and JetBrains Mono fonts (SIL OFL 1.1).
EOF

cat > "$STAGE/DEBIAN/postinst" <<'EOF'
#!/bin/sh
set -e
chmod -R go+rX /opt/MyGSNotesPlus || true
chmod 4755 /opt/MyGSNotesPlus/chrome-sandbox || true
if [ -f /etc/apparmor.d/abi/4.0 ]; then
  cp /opt/MyGSNotesPlus/apparmor-profile /etc/apparmor.d/mygsnotes-plus
  if command -v apparmor_parser >/dev/null 2>&1 && [ -d /sys/kernel/security/apparmor ]; then
    apparmor_parser --replace --write-cache --skip-read-cache /etc/apparmor.d/mygsnotes-plus || true
  fi
fi
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database -q /usr/share/applications || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t -f /usr/share/icons/hicolor || true
exit 0
EOF

cat > "$STAGE/DEBIAN/postrm" <<'EOF'
#!/bin/sh
set -e
if [ "$1" = "remove" ] || [ "$1" = "purge" ]; then
  if [ -f /etc/apparmor.d/mygsnotes-plus ]; then
    command -v apparmor_parser >/dev/null 2>&1 && [ -d /sys/kernel/security/apparmor ] && apparmor_parser --remove /etc/apparmor.d/mygsnotes-plus 2>/dev/null || true
    rm -f /etc/apparmor.d/mygsnotes-plus
  fi
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database -q /usr/share/applications || true
fi
exit 0
EOF
chmod 755 "$STAGE/DEBIAN/postinst" "$STAGE/DEBIAN/postrm"

SIZE=$(du -sk --exclude=DEBIAN "$STAGE" | cut -f1)
cat > "$STAGE/DEBIAN/control" <<EOF
Package: $PKG
Version: $VERSION
Architecture: $ARCH
Maintainer: Gustavo Salazar <gus.salazar66@gmail.com>
Installed-Size: $SIZE
Section: editors
Conflicts: gsnotes
Replaces: gsnotes
Priority: optional
Depends: libgtk-3-0t64 | libgtk-3-0, libnotify4, libnss3, libxss1, libxtst6, xdg-utils, libatspi2.0-0t64 | libatspi2.0-0, libuuid1, libsecret-1-0, libgbm1, libasound2t64 | libasound2, libdrm2, libxkbcommon0
Description: MyGSNotes+ — private, offline-first Markdown notes
 MyGSNotes+ (© 2026 Gustavo Salazar) is a desktop note-taking app inspired by Joplin. Notes are Markdown,
 stored on this computer, with notebooks, tags, tasks, wiki links and
 backlinks, a graph view, encrypted vault notebooks, version history,
 flashcards, projects with grid, kanban, timeline and chart views,
 calendar sync with Google, Outlook.com and CalDAV, a task board, offline text recognition (OCR),
 folder and WebDAV sync, and optional AI features through a local Ollama
 model or an OpenAI-compatible API.
EOF

bad=$(find "$STAGE" -path "$STAGE/DEBIAN" -prune -o \( -type d ! -perm -o=rx -print \) -o \( -type f ! -perm -o=r -print \))
if [ -n "$bad" ]; then echo "Not readable by normal users:"; echo "$bad"; exit 1; fi
dpkg-deb --root-owner-group -Zxz --build "$STAGE" "$OUT"
sha256sum "$OUT" | tee "$OUT.sha256"
ls -lh "$OUT"
