/* ============================================================
   Help and About
   ============================================================ */
const K = (...keys) => keys.map((k) => `<kbd>${k}</kbd>`).join('+');
const goLink = (view, label) => `<button class="linkbtn" data-view-go="${view}">${label}</button>`;

function helpTopics() {
  const desk = IS_DESKTOP;
  return [
    { id: 'start', title: 'Getting started', html: `
      <p>MyGSNotes+ keeps Markdown notes, tasks, projects and calendars on this device. There is no account and nothing to sign up for.</p>
      <ol>
        <li><b>Write a note.</b> Click <b>+ New</b> in the sidebar or press ${K('Alt', 'N')}. Give it a title, then write below it.</li>
        <li><b>Organize it.</b> Pick a notebook at the top of the editor and add tags. Notebooks can be nested: double-click a notebook to rename it or move it inside another.</li>
        <li><b>Find anything.</b> Press ${K('/')} to search, or ${K('Ctrl', 'K')} to open the command palette, which runs every action and jumps to any note by title.</li>
        <li><b>Plan your day.</b> <b>Today</b> opens a daily note made from the <i>Daily note</i> template, with your calendar's agenda filled in.</li>
        <li><b>Back up.</b> Open ${goLink('backup', 'Backup &amp; import')} and click <b>Back up now</b>, or turn on automatic backups. An amber dot in the sidebar means there is no recent backup.</li>
      </ol>` },
    { id: 'notes', title: 'Writing notes', html: `
      <ul>
        <li><b>Edit, Split, View:</b> the three buttons above the editor switch between source only, source and preview side by side, and preview only.</li>
        <li><b>Markdown:</b> <code># Heading</code>, <code>**bold**</code>, <code>*italic*</code>, <code>- list</code>, <code>- [ ] checkbox</code>, <code>\`code\`</code>, tables and links. Lists continue when you press Enter.</li>
        <li><b>Links between notes:</b> type <code>[[</code> and pick a note. A link to a note that does not exist yet creates it when clicked. Every note lists its <b>backlinks</b> at the bottom, and ${goLink('graph', 'Graph')} draws all the links.</li>
        <li><b>Templates:</b> any note in the <b>Templates</b> notebook is a template. Placeholders: <code>{{date}}</code>, <code>{{time}}</code>, <code>{{weekday}}</code>, <code>{{title}}</code> and <code>{{agenda}}</code> (that day's calendar events).</li>
        <li><b>Images and PDFs:</b> paste them into a note, or use the Attach button in the editor toolbar. Text inside images is read with OCR, and PDF text is extracted so both are searchable.</li>
        <li><b>Version history:</b> a snapshot is saved after about 90 seconds of editing and each time you press ${K('Ctrl', 'S')}. Open it from the palette (<i>Version history</i>) to compare or restore.</li>
        <li><b>Publish:</b> exports one note as a self-contained, read-only web page.</li>
      </ul>
      <h4>Search syntax</h4>
      <table class="help-table"><tr><td><code>tag:work</code></td><td>notes with the tag <i>work</i></td></tr><tr><td><code>in:Recipes</code></td><td>notes in the Recipes notebook</td></tr><tr><td><code>is:todo</code> / <code>is:done</code></td><td>open or completed tasks</td></tr></table>
      <p>Keyword search works offline. <b>Meaning</b> search finds notes by idea rather than exact words and needs an AI provider (see AI below).</p>` },
    { id: 'tasks', title: 'Tasks, board and reminders', html: `
      <ul>
        <li>Tick <b>Task</b> at the top of the editor to turn a note into a task, or use <i>New task</i> in the palette. Tasks can have a due date and a reminder.</li>
        <li>${goLink('tasks', 'Tasks')} lists open tasks. ${goLink('board', 'Board')} shows To do, In progress and Done columns; drag cards or use the arrow buttons.</li>
        <li><b>Reminders</b> appear as system notifications, or as in-app alerts if notifications are blocked. They only fire while MyGSNotes+ is open.</li>
      </ul>` },
    { id: 'projects', title: 'Projects', html: `
      <p>A project is a table of items with fields such as status, owner, budget or dates. Each item is a normal note, so it can hold text, links and attachments.</p>
      <ul>
        <li>Click <b>+</b> next to <b>Projects</b> in the sidebar and pick a template, or <b>⇪</b> to import a CSV file.</li>
        <li><b>Views:</b> Grid (edit cells inline, sort, totals), Kanban (columns from a select field), Calendar, Timeline, Charts and Gallery. Each view keeps its own filters and sort.</li>
        <li><b>Fields:</b> open <b>Fields</b> to add, rename, retype or delete them. Changes that would clear values ask first.</li>
        <li>Open an item to see its fields above the editor; <b>← Project</b> takes you back.</li>
      </ul>` },
    { id: 'calendar', title: 'Calendar sync', html: `
      <p>Open ${goLink('calendar', 'Calendar')} and click <b>Calendars</b> to connect an account.</p>
      <table class="help-table">
        <tr><td><b>Gmail / Google</b></td><td>Two-way. Needs a free Client ID from your own Google Cloud project; the dialog walks you through it.${desk ? '' : ' Desktop app only.'}</td></tr>
        <tr><td><b>Outlook.com / Hotmail / Microsoft 365</b></td><td>Two-way. Needs a free app registration (Client ID); the dialog has the steps.${desk ? '' : ' Desktop app only.'}</td></tr>
        <tr><td><b>iCloud, Fastmail, Yahoo, Nextcloud, CalDAV</b></td><td>Two-way. Server address, username and an <i>app password</i>.${desk ? '' : ' Desktop app only.'}</td></tr>
        <tr><td><b>Any .ics / webcal link</b></td><td>Read-only. Works in every version.</td></tr>
      </table>
      <ul>
        <li><b>Tasks in your calendar:</b> choose one writable calendar in the Calendars dialog. Tasks with a due date become all-day events there. Moving or renaming the event in Google or Outlook updates the task; adding ✓ to the start of the title marks it done.</li>
        <li><b>Meeting notes:</b> click an event and choose <b>Create meeting note</b>.</li>
        <li><b>Agenda:</b> <i>Insert today's agenda</i> in the palette, or <code>{{agenda}}</code> in a template.</li>
        <li>Vault notes and project items are never sent to a calendar.</li>
      </ul>` },
    { id: 'backup', title: 'Backup, restore and import', html: `
      <p>Everything is on ${goLink('backup', 'Backup &amp; import')}.</p>
      <ul>
        <li><b>Back up now</b> saves one <code>.json</code> file with all notes, notebooks, projects, cards and attachments.</li>
        <li><b>Automatic backups</b> write to a folder you choose every 6 hours, daily or weekly. Pick a folder that Dropbox or OneDrive already syncs to keep an off-device copy.</li>
        <li><b>Restore</b> compares the backup with this device, then <b>Merge</b> (keeps the newer copy of each note, deletes nothing) or <b>Replace everything</b>.</li>
        <li><b>Import:</b> Joplin <code>.jex</code>, OneNote (${desk ? '<code>.onepkg</code>, <code>.one</code>, OneDrive <code>.zip</code>, ' : ''}<code>.mht</code>, <code>.html</code>, <code>.docx</code>), Markdown folders (Obsidian, Joplin), Evernote <code>.enex</code> and CSV.${desk ? '' : ' OneNote notebook files need the desktop app.'}</li>
        <li><b>Export everything as Markdown</b> makes a <code>.zip</code> you can open in any other notes app.</li>
      </ul>` },
    { id: 'vaults', title: 'Vaults and privacy', html: `
      <ul>
        <li>A <b>vault notebook</b> (🔒 next to <b>Notebooks</b>) encrypts its notes with a password using AES-256-GCM. Titles, text, tags, history and attachments are all encrypted.</li>
        <li>Vaults lock after a few idle minutes (set in Settings) or with <i>Lock all vaults</i>.</li>
        <li><b>A forgotten vault password cannot be recovered.</b> Nobody, including the author, can open the notes without it.</li>
        <li>MyGSNotes+ has no account and sends no usage data. Data leaves this device only for features you turn on: sync, calendar accounts and an online AI provider.${desk ? '' : ' The web version also loads fonts and libraries from Google Fonts and jsDelivr.'}</li>
      </ul>` },
    { id: 'cards', title: 'Flashcards', html: `
      <p>Any line written as <code>question :: answer</code> becomes a flashcard. ${goLink('cards', 'Flashcards')} schedules reviews with spaced repetition: press ${K('Space')} to show the answer, then ${K('1')}–${K('4')} for Again, Hard, Good or Easy.</p>` },
    { id: 'ai', title: 'AI and Ask my notes', html: `
      <p>AI is optional. Choose a provider in ${goLink('settings', 'Settings')} → AI.</p>
      <ul>
        <li><b>Ollama</b> runs on your own computer and is private. Install it, run <code>ollama pull llama3.2</code> and <code>ollama pull nomic-embed-text</code>, then <b>Test connection</b>.${desk ? '' : ' In the web version, start it with <code>OLLAMA_ORIGINS=* ollama serve</code>.'}</li>
        <li><b>OpenAI-compatible API:</b> enter the address and your API key. Note text is sent to that provider. Vault notes are only ever sent to a local Ollama model.</li>
        <li>Without a provider, ${goLink('ask', 'Ask my notes')} still shows the best matching passages, and Summarize, Suggest tags and Make cards use offline methods.</li>
      </ul>` },
    { id: 'sync', title: 'Sync between devices', html: `
      <p>In ${goLink('settings', 'Settings')} → Sync:</p>
      <ul>
        <li><b>Folder sync</b> writes a sync file to a folder that Dropbox, OneDrive or Nextcloud already syncs.</li>
        <li><b>WebDAV</b> syncs straight to a server such as Nextcloud.</li>
        <li>Set a <b>sync passphrase</b> to encrypt the sync file end to end. Use the same passphrase on every device.</li>
        <li>If the same note changed on two devices, the most recent edit wins.</li>
      </ul>` },
    { id: 'keys', title: 'Keyboard shortcuts', html: `
      <table class="help-table keys">
        <tr><td>${K('F1')}</td><td>Open Help</td></tr>
        <tr><td>${K('?')}</td><td>Keyboard shortcuts (outside a text box)</td></tr>
        <tr><td>${K('Ctrl', 'K')}</td><td>Command palette</td></tr>
        <tr><td>${K('Alt', 'N')}</td><td>New note</td></tr>
        <tr><td>${K('Alt', 'Q')}</td><td>Quick capture</td></tr>
        ${desk ? `<tr><td>${K('Ctrl', 'Alt', 'N')}</td><td>Quick capture from any app (X11 sessions)</td></tr>` : ''}
        <tr><td>${K('/')}</td><td>Search</td></tr>
        <tr><td>${K('Ctrl', 'S')}</td><td>Save and keep a version</td></tr>
        <tr><td>${K('Ctrl', 'B')} / ${K('Ctrl', 'I')}</td><td>Bold / italic</td></tr>
        <tr><td>${K('[')}${K('[')}</td><td>Link to another note</td></tr>
        <tr><td>${K('Ctrl', 'Enter')}</td><td>Save in Quick capture</td></tr>
        <tr><td>${K('Esc')}</td><td>Close a dialog</td></tr>
        <tr><td>${K('Space')}, ${K('1')}–${K('4')}</td><td>Flashcards: show answer, grade</td></tr>
      </table>
      <p class="small muted">On a Mac, use ⌘ in place of Ctrl.</p>` },
    { id: 'desktop', title: desk ? 'Desktop app' : 'Install and run', html: desk ? `
      <ul>
        <li><b>Update:</b> install the new <code>.deb</code> over the old one with <code>sudo apt install ./mygsnotes-plus_VERSION_amd64.deb</code>. Your notes stay.</li>
        <li><b>Uninstall:</b> <code>sudo apt remove mygsnotes-plus</code>. Your notes stay in the data folder until you delete it.</li>
        <li><b>Data folder:</b> <code>~/.config/MyGSNotesPlus</code> (<button class="linkbtn" data-hact="opendata">open it</button>). Notes from the earlier GSNotes app were copied there on first start.</li>
        <li><b>Launcher actions:</b> right-click the MyGSNotes+ icon for <i>Quick capture</i> and <i>Today's note</i>.</li>
        <li>The desktop app works fully offline. Dictation is not available in it; use your system's dictation instead.</li>
      </ul>` : `
      <ul>
        <li><b>Install as an app:</b> in Chrome or Edge, use the install icon in the address bar, or <b>Install MyGSNotes+</b> in ${goLink('settings', 'Settings')}.</li>
        <li><b>Linux desktop app:</b> <code>sudo apt install ./mygsnotes-plus_26.10.03_amd64.deb</code>, then open MyGSNotes+ from the app menu.</li>
        <li><b>Run the web version yourself:</b> in the folder that contains <code>index.html</code>, run <code>python3 -m http.server 8080</code> and open <code>http://localhost:8080</code>.</li>
        <li>Notes are stored in this browser for this exact address. <code>localhost:8080</code> and <code>127.0.0.1:8080</code> count as different places, so always use the same one.</li>
      </ul>` },
    { id: 'trouble', title: 'Troubleshooting', html: `
      <dl class="help-dl">
        ${desk ? `<dt>The app does not start on Ubuntu 23.10 or later</dt><dd>Reinstall with <code>sudo apt install ./mygsnotes-plus_…deb</code> (not <code>dpkg -i</code>) so the AppArmor profile and missing libraries are installed, then run <code>mygsnotes-plus</code> in a terminal to see any error.</dd>
        <dt>${K('Ctrl', 'Alt', 'N')} does nothing outside the app</dt><dd>Some Wayland desktops refuse global shortcuts. Use the launcher's <i>Quick capture</i> action, or add a custom shortcut in your desktop settings that runs <code>mygsnotes-plus --capture</code>.</dd>
        <dt>Calendar says sign-ins are stored unencrypted</dt><dd>No system keyring was found. Install and unlock GNOME Keyring or KWallet, then remove and reconnect the calendar account.</dd>` : `
        <dt>My notes disappeared</dt><dd>Notes live in the browser for one address. Check you opened the same address as before (for example <code>http://localhost:8080</code>), the same browser and the same browser profile. Private windows erase notes when closed.</dd>
        <dt>A calendar or WebDAV server refuses to connect</dt><dd>Browsers block servers that do not allow cross-origin requests. Use the desktop app, which has no such limit, or an .ics link for read-only calendars.</dd>`}
        <dt>A calendar account shows an error</dt><dd>Click <b>Sync</b> to retry. If it says the sign-in was rejected, remove the account in <b>Calendars</b> and connect it again.</dd>
        <dt>Ollama does not connect</dt><dd>Check it is running with <code>ollama list</code>.${desk ? '' : ' In the web version it must be started with <code>OLLAMA_ORIGINS=*</code>.'} The address is normally <code>http://localhost:11434</code>.</dd>
        <dt>Reminders did not appear</dt><dd>Reminders only fire while MyGSNotes+ is open. Allow notifications when asked, or check your system's notification settings.</dd>
        <dt>A vault will not unlock</dt><dd>Passwords are case-sensitive. A forgotten password cannot be reset.</dd>
        <dt>Start over</dt><dd>Back up first, then use <b>Erase all data on this device</b> in ${goLink('settings', 'Settings')}.</dd>
      </dl>` },
  ];
}

let helpQuery = '';
function openHelp(topic) { S.ui.helpTopic = topic || null; helpQuery = ''; go('help'); }
function openAbout(anchor) { S.ui.aboutAnchor = anchor || null; go('about'); }

function viewHelp(V) {
  const topics = helpTopics();
  V.innerHTML = viewHead('Help', `<input class="input help-search" id="help-q" type="search" placeholder="Search help…" aria-label="Search help" value="${esc(helpQuery)}">`) +
    `<div class="view-body"><div class="help">
      <nav class="help-toc" aria-label="Help topics">${topics.map((t) => `<a href="#help-${t.id}" data-htopic="${t.id}">${esc(t.title)}</a>`).join('')}
        <a href="#" data-hact="about" class="help-toc-about">About MyGSNotes+</a></nav>
      <div class="help-main">
        <p class="help-none muted" hidden>No help topic matches “<span></span>”. Try a shorter word.</p>
        ${topics.map((t) => `<section class="help-sec" id="help-${t.id}" data-topic="${t.id}"><h3>${esc(t.title)}</h3>${t.html}</section>`).join('')}
        <p class="small muted help-foot">${APP_NAME} ${APP_VERSION} · ${APP_COPYRIGHT} · By Gustavo Salazar</p>
      </div></div></div>`;
  if (helpQuery) filterHelp();
  if (S.ui.helpTopic) { const el = $('#help-' + S.ui.helpTopic); S.ui.helpTopic = null; if (el) requestAnimationFrame(() => { el.scrollIntoView({ block: 'start' }); el.classList.add('flash'); }); }
}
function filterHelp() {
  const terms = helpQuery.toLowerCase().split(/\s+/).filter(Boolean);
  let shown = 0;
  for (const sec of $$('.help-sec')) {
    const ok = terms.every((t) => sec.textContent.toLowerCase().includes(t));
    sec.hidden = !ok; shown += ok;
    const a = $(`.help-toc [data-htopic="${sec.dataset.topic}"]`); if (a) a.hidden = !ok;
  }
  const none = $('.help-none'); if (none) { none.hidden = shown > 0; $('span', none).textContent = helpQuery; }
}

const LICENCES = [
  ['marked', 'Markdown rendering', 'MIT'],
  ['DOMPurify', 'Safe HTML in notes', 'Apache-2.0 or MPL-2.0'],
  ['pdf.js', 'PDF text', 'Apache-2.0'],
  ['Tesseract.js', 'OCR (reading text in images)', 'Apache-2.0'],
  ['mammoth', 'Word (.docx) import', 'BSD-2-Clause'],
  ['ical.js', 'Calendar (.ics) parsing', 'MPL-2.0'],
  ['Joplin onenote-converter', 'OneNote notebook import (desktop)', 'MPL-2.0'],
  ['Electron and Chromium', 'Desktop app shell', 'MIT / BSD'],
  ['Atkinson Hyperlegible, Bricolage Grotesque, JetBrains Mono', 'Fonts', 'SIL OFL 1.1'],
];

async function viewAbout(V) {
  const edition = IS_DESKTOP ? 'Desktop app for Linux' : IN_FRAME ? 'Web preview' : matchMedia('(display-mode: standalone)').matches ? 'Installed web app' : 'Web app';
  const notes = liveNotes().length, books = [...S.folders.values()].filter((f) => !f.deleted).length;
  V.innerHTML = viewHead('About') + `<div class="view-body"><div class="about-page">
    <div class="about-hero">
      <div class="brand-mark huge" aria-hidden="true">GS+</div>
      <div><h1 class="about-title">${APP_NAME}</h1>
        <p class="about-ver mono">Version ${APP_VERSION}</p>
        <p class="about-copy">${APP_COPYRIGHT}. All rights reserved.</p>
        <p class="about-by">By Gustavo Salazar</p></div>
    </div>
    <p class="about-tag">Private, offline-first Markdown notes with tasks, projects, calendars and flashcards.</p>
    <div class="row about-actions"><button class="btn primary" data-hact="help">Open Help</button><button class="btn" data-hact="copyinfo">Copy version info</button>${IS_DESKTOP ? '<button class="btn" data-hact="opendata">Open data folder</button>' : ''}</div>
    <section><h3>This copy</h3><table class="help-table about-info" id="about-info">
      <tr><td>Edition</td><td>${edition}</td></tr>
      <tr><td>Version</td><td class="mono">${APP_VERSION}</td></tr>
      <tr><td>Your data</td><td>${notes} note${notes === 1 ? '' : 's'}, ${books} notebook${books === 1 ? '' : 's'}, ${S.projects.size} project${S.projects.size === 1 ? '' : 's'}</td></tr>
      <tr><td>Stored in</td><td id="about-where">${IS_DESKTOP ? '…' : `This browser, for <span class="mono">${esc(location.origin === 'null' ? 'this page' : location.origin)}</span>`}</td></tr>
      <tr><td>Last backup</td><td>${S.lastBackupAt ? new Date(S.lastBackupAt).toLocaleString() : 'None yet — ' + goLink('backup', 'back up now')}</td></tr>
    </table></section>
    <section><h3>What's new in ${APP_VERSION}</h3><ul class="about-news">
      <li>New name: MyGSNotes+.${IS_DESKTOP ? " Notes from the GSNotes desktop app carry over." : ""}</li>
      <li>Calendar sync with Gmail, Outlook.com/Hotmail, Microsoft 365, iCloud, CalDAV and .ics links, including tasks as calendar events and meeting notes.</li>
      <li>This Help page and About page, with ${K('F1')} for Help.</li>
      <li>Earlier: Backup &amp; import (Joplin, OneNote, Markdown folders) and Projects with Grid, Kanban, Calendar, Timeline, Charts and Gallery views.</li>
    </ul></section>
    <section id="about-licences"><h3>Third-party software</h3>
      <p class="small muted">MyGSNotes+ is built with these open-source components. Each keeps its own licence.${IS_DESKTOP ? ' Full texts: <span class="mono">/usr/share/doc/mygsnotes-plus/copyright</span>.' : ''}</p>
      <table class="help-table"><thead><tr><th>Component</th><th>Used for</th><th>Licence</th></tr></thead><tbody>${LICENCES.map(([n, u, l]) => `<tr><td>${n}</td><td>${u}</td><td class="mono small">${l}</td></tr>`).join('')}</tbody></table>
    </section>
  </div></div>`;
  if (S.ui.aboutAnchor) { const el = $('#about-' + S.ui.aboutAnchor); S.ui.aboutAnchor = null; el?.scrollIntoView({ block: 'start' }); }
  if (IS_DESKTOP && window.gsDesktop.appInfo) {
    const i = await window.gsDesktop.appInfo().catch(() => null); const w = $('#about-where');
    if (i && w) {
      w.innerHTML = `<span class="mono">${esc(i.dataDir)}</span>`;
      $('#about-info').insertAdjacentHTML('beforeend', `<tr><td>Built with</td><td class="mono small">Electron ${esc(i.electron)} · Chromium ${esc(i.chrome)} · ${esc(i.platform)}${i.session ? ' · ' + esc(i.session) : ''}</td></tr>`);
    }
  }
}
async function versionInfoText() {
  const lines = [`${APP_NAME} ${APP_VERSION}`, `${APP_COPYRIGHT}. By Gustavo Salazar.`];
  if (IS_DESKTOP && window.gsDesktop.appInfo) { const i = await window.gsDesktop.appInfo().catch(() => null); if (i) lines.push(`Desktop app · Electron ${i.electron} · Chromium ${i.chrome} · ${i.platform}${i.session ? ' · ' + i.session : ''}`, `Data: ${i.dataDir}`); }
  else lines.push(`Web · ${navigator.userAgent}`);
  return lines.join('\n');
}

function helpEvents() {
  const V = $('#view');
  V.addEventListener('input', (e) => { if (e.target.id === 'help-q') { helpQuery = e.target.value; filterHelp(); } });
  V.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-htopic]');
    if (a) { e.preventDefault(); if (helpQuery) { helpQuery = ''; $('#help-q').value = ''; filterHelp(); } const el = $('#help-' + a.dataset.htopic); el?.scrollIntoView({ block: 'start', behavior: 'smooth' }); el?.classList.remove('flash'); void el?.offsetWidth; el?.classList.add('flash'); return; }
    const b = e.target.closest('[data-hact]'); if (!b) return;
    e.preventDefault();
    if (b.dataset.hact === 'help') return openHelp();
    if (b.dataset.hact === 'about') return openAbout();
    if (b.dataset.hact === 'opendata') return window.gsDesktop?.openDataFolder?.();
    if (b.dataset.hact === 'copyinfo') {
      const t = await versionInfoText();
      try { await navigator.clipboard.writeText(t); toast('Version info copied'); }
      catch { openDialog(`${dlgHead('Version info')}<div class="dialog-b"><textarea class="input" rows="5" readonly style="width:100%;font:12px var(--f-mono)">${esc(t)}</textarea></div><div class="dialog-f"><button class="btn primary" data-close>Close</button></div>`); }
    }
  });
}
function helpCommand(cmd) {
  if (cmd === 'help') return openHelp();
  if (cmd === 'help:keys') return openHelp('keys');
  if (cmd === 'help:trouble') return openHelp('trouble');
  if (cmd === 'about') return openAbout();
  if (cmd === 'about:licences') return openAbout('licences');
}
