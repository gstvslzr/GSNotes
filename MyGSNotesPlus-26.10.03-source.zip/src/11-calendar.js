/* ============================================================
   Calendar sync: Google Calendar, Outlook.com / Hotmail / Microsoft 365,
   CalDAV (iCloud, Fastmail, Nextcloud, Yahoo…), and .ics links/files.
   Events are shown in the Calendar view; tasks with due dates can be
   pushed to one calendar and kept in sync both ways.
   ============================================================ */
const CAL = { events: new Map(), busy: false, bases: null, info: null };
const calCfg = () => (S.settings.calendars ||= { accounts: [], pushTarget: null, autoSyncMin: 15, googleClientId: '', googleClientSecret: '', msClientId: '' });
const calAcct = (id) => calCfg().accounts.find((a) => a.id === id);
const calOf = (a, id) => a?.calendars.find((c) => c.id === id);
const PROVIDER_LABEL = { google: 'Google', microsoft: 'Microsoft', caldav: 'CalDAV', ics: 'Subscribed link', file: 'Imported file' };
const isoZ = (ms) => new Date(ms).toISOString().replace(/\.\d{3}Z$/, 'Z');
const nextDay = (d) => dayToYmd(parseDay(d) + 1);
const enc = encodeURIComponent;

/* ---------- HTTP (desktop: through the app with stored credentials; web: plain fetch for public links) ---------- */
async function calHttp(acct, url, opts = {}) {
  if (window.gsDesktop?.calRequest) {
    const r = await window.gsDesktop.calRequest({ accountId: acct?.credId || '', url, method: opts.method || 'GET', headers: opts.headers || {}, body: opts.body ?? null });
    if (r.error) throw new Error(r.error === 'Failed to fetch' || /ERR_/.test(r.error) ? 'Could not reach the calendar server. Check your connection and the address.' : r.error);
    return r;
  }
  if (acct && !['ics'].includes(acct.provider)) throw new Error('Calendar accounts need the MyGSNotes+ desktop app.');
  let res;
  try { res = await fetch(url, { method: opts.method || 'GET', headers: opts.headers, body: opts.body, cache: 'no-store' }); }
  catch { throw new Error('This link can’t be read from the web version because the server blocks browser access. Use the desktop app, or download the .ics file and import it.'); }
  return { status: res.status, body: await res.text(), headers: { etag: res.headers.get('etag') || '' } };
}
function calOk(r, what) {
  if (r.status >= 200 && r.status < 300) return r;
  let msg = ''; try { const j = JSON.parse(r.body); msg = j.error?.message || j.error_description || (typeof j.error === 'string' ? j.error : '') || ''; } catch {}
  if (r.status === 401) msg = msg || 'the server rejected the sign-in. Remove the account and connect it again.';
  if (r.status === 403) msg = msg || 'permission denied.';
  throw new Error(`${what} failed (${r.status})${msg ? ': ' + msg : ''}`);
}
const jsonOf = (r) => { try { return JSON.parse(r.body || '{}'); } catch { throw new Error('The calendar server sent an unexpected reply.'); } };

/* ---------- iCalendar parsing (ical.js, loaded on demand) ---------- */
let ICAL_ = null;
async function loadIcal() {
  if (ICAL_) return ICAL_;
  const url = window.GS_LIBS?.ical ? new URL(window.GS_LIBS.ical, location.href).href : 'https://cdn.jsdelivr.net/npm/ical.js@2.2.1/dist/ical.min.js';
  const m = await import(url); ICAL_ = m.default || m; return ICAL_;
}
function zonedToUtc(y, mo, d, h, mi, s, tz) { // wall time in an IANA zone → UTC ms
  let t = Date.UTC(y, mo - 1, d, h, mi, s);
  for (let i = 0; i < 2; i++) {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).formatToParts(new Date(t)).map((x) => [x.type, x.value]));
    const asUtc = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second);
    t -= asUtc - Date.UTC(y, mo - 1, d, h, mi, s);
  }
  return t;
}
function icalTimeToMs(t, tzidHint) {
  if (t.zone && t.zone.tzid !== 'floating') return t.toJSDate().getTime();
  if (tzidHint) { try { new Intl.DateTimeFormat('en-US', { timeZone: tzidHint }); return zonedToUtc(t.year, t.month, t.day, t.hour, t.minute, t.second, tzidHint); } catch {} }
  return new Date(t.year, t.month - 1, t.day, t.hour, t.minute, t.second).getTime(); // floating → local time
}
const icalDate = (t) => `${t.year}-${pad2(t.month)}-${pad2(t.day)}`;
async function parseIcs(text, from, to) {
  const ICAL = await loadIcal();
  let comp;
  try { comp = new ICAL.Component(ICAL.parse(text)); } catch { throw new Error('That isn’t a valid calendar (.ics) file.'); }
  const roots = comp.name === 'vcalendar' ? [comp] : comp.getAllSubcomponents('vcalendar');
  const out = [];
  for (const cal of roots.length ? roots : [comp]) {
    for (const tz of cal.getAllSubcomponents('vtimezone')) { try { ICAL.TimezoneService.register(tz); } catch {} }
    const masters = new Map(); const exceptions = [];
    for (const ve of cal.getAllSubcomponents('vevent')) {
      if ((ve.getFirstPropertyValue('status') || '').toUpperCase() === 'CANCELLED' && !ve.hasProperty('recurrence-id')) continue;
      const e = new ICAL.Event(ve);
      if (ve.hasProperty('recurrence-id')) exceptions.push(e); else masters.set(e.uid || uid(), e);
    }
    for (const ex of exceptions) { const m = masters.get(ex.uid); if (m) { try { m.relateException(ex); } catch {} } else masters.set(ex.uid + ':' + ex.recurrenceId, ex); }
    const mk = (item, s, e, key) => {
      const tzHint = item.component.getFirstProperty('dtstart')?.getParameter('tzid');
      const allDay = s.isDate;
      const start = allDay ? icalDate(s) : icalTimeToMs(s, tzHint);
      let end = e ? (allDay ? icalDate(e) : icalTimeToMs(e, tzHint)) : null;
      if (allDay && (!end || end <= start)) end = nextDay(start);
      if (!allDay && (!end || end < start)) end = start;
      const vc = item.component;
      const lm = vc.getFirstPropertyValue('last-modified') || vc.getFirstPropertyValue('dtstamp');
      return {
        remoteId: item.uid, occ: key, title: item.summary || '(No title)', allDay, start, end, location: item.location || '', description: item.description || '',
        url: String(vc.getFirstPropertyValue('url') || ''), status: (vc.getFirstPropertyValue('status') || '').toUpperCase(),
        attendees: (item.attendees || []).map((a) => ({ email: String(a.getFirstValue() || '').replace(/^mailto:/i, ''), name: a.getParameter('cn') || '', status: (a.getParameter('partstat') || '').toLowerCase() })).slice(0, 100),
        updated: lm ? lm.toJSDate().getTime() : 0, gsId: vc.getFirstPropertyValue('x-gsnotes-id') || '', recurring: false,
      };
    };
    const inRange = (ev) => { const s = typeof ev.start === 'string' ? parseDay(ev.start) * 864e5 : ev.start; const e = typeof ev.end === 'string' ? parseDay(ev.end) * 864e5 : ev.end; return e >= from && s <= to; };
    for (const [key, e] of masters) {
      if (e.isRecurring()) {
        const it = e.iterator(); let next, guard = 0;
        while ((next = it.next()) && guard++ < 3000) {
          const det = e.getOccurrenceDetails(next);
          const ev = mk(det.item, det.startDate, det.endDate, next.toString()); ev.recurring = true;
          if (det.item.component.getFirstPropertyValue('status')?.toUpperCase?.() === 'CANCELLED') continue;
          const s = typeof ev.start === 'string' ? parseDay(ev.start) * 864e5 : ev.start;
          if (s > to) break;
          if (inRange(ev)) out.push(ev);
        }
      } else { const ev = mk(e, e.startDate, e.endDate, ''); if (inRange(ev)) out.push(ev); }
    }
  }
  return out;
}
/* iCalendar writer (CalDAV events and .ics export) */
const icsText = (s) => String(s || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
function icsFold(line) { const out = []; let cur = ''; for (const ch of line) { if (new TextEncoder().encode(cur + ch).length > 73) { out.push(cur); cur = ' ' + ch; } else cur += ch; } out.push(cur); return out.join('\r\n'); }
const icsStamp = (ms = now()) => new Date(ms).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
function icsEvent({ uidv, title, date, description, gsId, done }) {
  return ['BEGIN:VEVENT', `UID:${uidv}`, `DTSTAMP:${icsStamp()}`, `LAST-MODIFIED:${icsStamp()}`, `DTSTART;VALUE=DATE:${date.replace(/-/g, '')}`, `DTEND;VALUE=DATE:${nextDay(date).replace(/-/g, '')}`,
    `SUMMARY:${icsText((done ? '✓ ' : '') + title)}`, description ? `DESCRIPTION:${icsText(description)}` : '', 'TRANSP:TRANSPARENT', gsId ? `X-GSNOTES-ID:${gsId}` : '', 'END:VEVENT'].filter(Boolean).map(icsFold).join('\r\n');
}
const icsWrap = (body, name) => ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//MyGSNotes+//MyGSNotes+//EN', 'CALSCALE:GREGORIAN', name ? `X-WR-CALNAME:${icsText(name)}` : '', body, 'END:VCALENDAR'].filter(Boolean).join('\r\n') + '\r\n';

/* ---------- providers ---------- */
const gBase = () => CAL.bases?.google || 'https://www.googleapis.com/calendar/v3';
const msBase = () => CAL.bases?.graph || 'https://graph.microsoft.com/v1.0';
const stripHtml = (s) => String(s || '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n').replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();
function taskPayload(n) { return { title: n.title || 'Untitled', date: n.due, done: !!n.done, description: (stripMd(n.body).slice(0, 900) + '\n\n— Task from MyGSNotes+').trim(), gsId: n.id }; }

const PROV = {
  google: {
    async list(a) {
      const r = calOk(await calHttp(a, gBase() + '/users/me/calendarList?minAccessRole=reader&maxResults=250'), 'Listing calendars');
      return (jsonOf(r).items || []).map((c) => ({ id: c.id, name: c.summaryOverride || c.summary || c.id, primary: !!c.primary, writable: ['owner', 'writer'].includes(c.accessRole) }));
    },
    map(x) {
      const allDay = !!x.start?.date;
      const video = x.hangoutLink || (x.conferenceData?.entryPoints || []).find((p) => p.entryPointType === 'video')?.uri || '';
      return { remoteId: x.id, occ: '', title: x.summary || '(No title)', allDay, start: allDay ? x.start.date : Date.parse(x.start?.dateTime), end: allDay ? x.end?.date : Date.parse(x.end?.dateTime),
        location: x.location || '', description: stripHtml(x.description), url: x.htmlLink || '', meet: video, recurring: !!x.recurringEventId,
        attendees: (x.attendees || []).map((p) => ({ name: p.displayName || '', email: p.email || '', status: p.responseStatus || '' })), updated: Date.parse(x.updated || '') || 0, gsId: x.extendedProperties?.private?.gsnotesId || '' };
    },
    async fetch(a, c, from, to) {
      const out = []; let page = '';
      do {
        const q = new URLSearchParams({ timeMin: isoZ(from), timeMax: isoZ(to), singleEvents: 'true', maxResults: '2500', showDeleted: 'false' }); if (page) q.set('pageToken', page);
        const j = jsonOf(calOk(await calHttp(a, `${gBase()}/calendars/${enc(c.id)}/events?${q}`), `Reading “${c.name}”`));
        for (const x of j.items || []) if (x.status !== 'cancelled' && x.start) out.push(this.map(x));
        page = j.nextPageToken || '';
      } while (page && out.length < 20000);
      return out;
    },
    body(t) { return { summary: (t.done ? '✓ ' : '') + t.title, description: t.description, start: { date: t.date }, end: { date: nextDay(t.date) }, transparency: 'transparent', extendedProperties: { private: { gsnotesId: t.gsId } } }; },
    async create(a, c, t) { return this.map(jsonOf(calOk(await calHttp(a, `${gBase()}/calendars/${enc(c.id)}/events`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.body(t)) }), 'Adding the event'))); },
    async update(a, c, id, t) { return this.map(jsonOf(calOk(await calHttp(a, `${gBase()}/calendars/${enc(c.id)}/events/${enc(id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.body(t)) }), 'Updating the event'))); },
    async remove(a, c, id) { const r = await calHttp(a, `${gBase()}/calendars/${enc(c.id)}/events/${enc(id)}`, { method: 'DELETE' }); if (![200, 204, 404, 410].includes(r.status)) calOk(r, 'Removing the event'); },
  },
  microsoft: {
    async list(a) {
      const r = calOk(await calHttp(a, msBase() + '/me/calendars?$top=100'), 'Listing calendars');
      return (jsonOf(r).value || []).map((c) => ({ id: c.id, name: c.name, primary: !!c.isDefaultCalendar, writable: c.canEdit !== false }));
    },
    map(x) {
      const t = (v) => Date.parse(String(v || '').slice(0, 19) + 'Z');
      const allDay = !!x.isAllDay;
      return { remoteId: x.id, occ: '', title: x.subject || '(No title)', allDay, start: allDay ? String(x.start?.dateTime).slice(0, 10) : t(x.start?.dateTime), end: allDay ? String(x.end?.dateTime).slice(0, 10) : t(x.end?.dateTime),
        location: x.location?.displayName || '', description: x.bodyPreview || '', url: x.webLink || '', meet: x.onlineMeeting?.joinUrl || '', recurring: x.type === 'occurrence' || x.type === 'exception',
        attendees: (x.attendees || []).map((p) => ({ name: p.emailAddress?.name || '', email: p.emailAddress?.address || '', status: p.status?.response || '' })), updated: Date.parse(x.lastModifiedDateTime || '') || 0, gsId: '' };
    },
    async fetch(a, c, from, to) {
      const out = [];
      let url = `${msBase()}/me/calendars/${enc(c.id)}/calendarView?` + new URLSearchParams({ startDateTime: isoZ(from), endDateTime: isoZ(to), $top: '250', $select: 'id,subject,bodyPreview,start,end,isAllDay,location,attendees,webLink,onlineMeeting,lastModifiedDateTime,isCancelled,type' });
      while (url && out.length < 20000) {
        const j = jsonOf(calOk(await calHttp(a, url, { headers: { Prefer: 'outlook.timezone="UTC"' } }), `Reading “${c.name}”`));
        for (const x of j.value || []) if (!x.isCancelled) out.push(this.map(x));
        url = j['@odata.nextLink'] || '';
      }
      return out;
    },
    body(t) { return { subject: (t.done ? '✓ ' : '') + t.title, body: { contentType: 'text', content: t.description }, start: { dateTime: `${t.date}T00:00:00`, timeZone: 'UTC' }, end: { dateTime: `${nextDay(t.date)}T00:00:00`, timeZone: 'UTC' }, isAllDay: true, showAs: 'free' }; },
    async create(a, c, t) { return this.map(jsonOf(calOk(await calHttp(a, `${msBase()}/me/calendars/${enc(c.id)}/events`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.body(t)) }), 'Adding the event'))); },
    async update(a, c, id, t) { return this.map(jsonOf(calOk(await calHttp(a, `${msBase()}/me/events/${enc(id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.body(t)) }), 'Updating the event'))); },
    async remove(a, c, id) { const r = await calHttp(a, `${msBase()}/me/events/${enc(id)}`, { method: 'DELETE' }); if (![200, 204, 404, 410].includes(r.status)) calOk(r, 'Removing the event'); },
  },
  caldav: {
    xml(s) { return new DOMParser().parseFromString(s, 'application/xml'); },
    async dav(a, url, method, body, depth) { return calHttp(a, url, { method, headers: { 'Content-Type': 'application/xml; charset=utf-8', Depth: String(depth) }, body }); },
    hrefIn(doc, tag) { const el = doc.getElementsByTagNameNS('DAV:', tag)[0] || doc.getElementsByTagNameNS('urn:ietf:params:xml:ns:caldav', tag)[0]; return el?.getElementsByTagNameNS('DAV:', 'href')[0]?.textContent?.trim() || ''; },
    async list(a) {
      let base = a.url.trim(); if (!/\/$/.test(base)) base += '/';
      const pf = `<?xml version="1.0"?><d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><d:current-user-principal/><c:calendar-home-set/><d:resourcetype/><d:displayname/></d:prop></d:propfind>`;
      let r = await this.dav(a, base, 'PROPFIND', pf, 0);
      if ([404, 405, 501].includes(r.status) || (r.status >= 300 && r.status < 400)) { base = new URL('/.well-known/caldav', base).href; r = await this.dav(a, base, 'PROPFIND', pf, 0); }
      calOk(r, 'Connecting to the CalDAV server');
      let doc = this.xml(r.body);
      if (doc.getElementsByTagNameNS('urn:ietf:params:xml:ns:caldav', 'calendar').length) return [{ id: base, name: doc.getElementsByTagNameNS('DAV:', 'displayname')[0]?.textContent || 'Calendar', writable: true }];
      let home = this.hrefIn(doc, 'calendar-home-set');
      if (!home) {
        const principal = this.hrefIn(doc, 'current-user-principal'); if (!principal) throw new Error('This address isn’t a CalDAV server. Check the server address.');
        const pr = calOk(await this.dav(a, new URL(principal, base).href, 'PROPFIND', pf, 0), 'Finding your calendars');
        home = this.hrefIn(this.xml(pr.body), 'calendar-home-set'); if (!home) throw new Error('The server did not say where your calendars are.');
      }
      const homeUrl = new URL(home, base).href;
      const lr = calOk(await this.dav(a, homeUrl, 'PROPFIND', `<?xml version="1.0"?><d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><d:displayname/><d:resourcetype/><c:supported-calendar-component-set/><d:current-user-privilege-set/></d:prop></d:propfind>`, 1), 'Listing calendars');
      const out = [];
      for (const resp of this.xml(lr.body).getElementsByTagNameNS('DAV:', 'response')) {
        if (!resp.getElementsByTagNameNS('urn:ietf:params:xml:ns:caldav', 'calendar').length) continue;
        const comps = [...resp.getElementsByTagNameNS('urn:ietf:params:xml:ns:caldav', 'comp')].map((x) => (x.getAttribute('name') || '').toUpperCase());
        if (comps.length && !comps.includes('VEVENT')) continue;
        const href = resp.getElementsByTagNameNS('DAV:', 'href')[0]?.textContent?.trim(); if (!href) continue;
        const privs = [...resp.getElementsByTagNameNS('DAV:', 'privilege')].map((p) => p.firstElementChild?.localName);
        out.push({ id: new URL(href, homeUrl).href, name: resp.getElementsByTagNameNS('DAV:', 'displayname')[0]?.textContent?.trim() || decodeURIComponent(href.split('/').filter(Boolean).pop() || 'Calendar'), writable: !privs.length || privs.includes('write') || privs.includes('all') || privs.includes('write-content') });
      }
      if (!out.length) throw new Error('No event calendars were found on this account.');
      return out;
    },
    async fetch(a, c, from, to) {
      const q = `<?xml version="1.0"?><c:calendar-query xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><d:getetag/><c:calendar-data/></d:prop><c:filter><c:comp-filter name="VCALENDAR"><c:comp-filter name="VEVENT"><c:time-range start="${icsStamp(from)}" end="${icsStamp(to)}"/></c:comp-filter></c:comp-filter></c:filter></c:calendar-query>`;
      const r = calOk(await this.dav(a, c.id, 'REPORT', q, 1), `Reading “${c.name}”`);
      const out = [];
      for (const resp of this.xml(r.body).getElementsByTagNameNS('DAV:', 'response')) {
        const href = resp.getElementsByTagNameNS('DAV:', 'href')[0]?.textContent?.trim();
        const data = resp.getElementsByTagNameNS('urn:ietf:params:xml:ns:caldav', 'calendar-data')[0]?.textContent;
        if (!href || !data) continue;
        for (const ev of await parseIcs(data, from, to)) { ev.uidv = ev.remoteId; ev.remoteId = new URL(href, c.id).href; out.push(ev); }
      }
      return out;
    },
    async put(a, url, t, create) {
      const body = icsWrap(icsEvent({ uidv: 'gsnotes-' + t.gsId, ...t }));
      let r = await calHttp(a, url, { method: 'PUT', headers: { 'Content-Type': 'text/calendar; charset=utf-8', ...(create ? { 'If-None-Match': '*' } : {}) }, body });
      if (create && r.status === 412) r = await calHttp(a, url, { method: 'PUT', headers: { 'Content-Type': 'text/calendar; charset=utf-8' }, body });
      calOk(r, create ? 'Adding the event' : 'Updating the event');
      return { remoteId: url, title: (t.done ? '✓ ' : '') + t.title, allDay: true, start: t.date, end: nextDay(t.date), updated: now() };
    },
    create(a, c, t) { return this.put(a, new URL(`gsnotes-${t.gsId}.ics`, c.id.endsWith('/') ? c.id : c.id + '/').href, t, true); },
    update(a, c, id, t) { return this.put(a, id, t, false); },
    async remove(a, c, id) { const r = await calHttp(a, id, { method: 'DELETE' }); if (![200, 204, 404, 410].includes(r.status)) calOk(r, 'Removing the event'); },
  },
  ics: {
    async list(a) { return [{ id: 'feed', name: a.label, writable: false }]; },
    async fetch(a, c, from, to) {
      const url = a.url.replace(/^webcal:/i, 'https:');
      const r = calOk(await calHttp(a, url), `Reading “${a.label}”`);
      if (!/BEGIN:VCALENDAR/i.test(r.body)) throw new Error('That link didn’t return a calendar. Make sure it’s the .ics (iCal) address.');
      return parseIcs(r.body, from, to);
    },
  },
  file: { async list() { return []; }, async fetch() { return null; } },
};

/* ---------- event store ---------- */
const evKey = (aId, cId, ev) => `${aId}|${cId}|${ev.remoteId}|${ev.occ || ''}|${ev.start}`;
async function storeEvents(a, c, evs) {
  for (const k of [...CAL.events.keys()]) if (k.startsWith(`${a.id}|${c.id}|`)) CAL.events.delete(k);
  for (const ev of evs) { ev.accountId = a.id; ev.calendarId = c.id; ev.key = evKey(a.id, c.id, ev); CAL.events.set(ev.key, ev); }
  await DB.put('events', { id: `${a.id}|${c.id}`, events: evs });
}
async function loadEvents() {
  try { for (const rec of await DB.all('events')) for (const ev of rec.events || []) { ev.key ||= evKey(ev.accountId, ev.calendarId, ev); CAL.events.set(ev.key, ev); } } catch {}
}
function findRemote(aId, cId, remoteId) { for (const ev of CAL.events.values()) if (ev.accountId === aId && ev.calendarId === cId && ev.remoteId === remoteId) return ev; return null; }
const evStartMs = (ev) => typeof ev.start === 'string' ? new Date(...ev.start.split('-').map((x, i) => i === 1 ? x - 1 : +x)).getTime() : ev.start;
function evDays(ev) { // local day keys an event covers
  if (ev.allDay) { const out = []; const s0 = parseDay(ev.start); const e0 = Math.max(parseDay(ev.end) || 0, s0 + 1); for (let d = s0; d < e0 && out.length < 62; d++) out.push(dayToYmd(d)); return out; }
  const out = []; const s = new Date(ev.start); const e = new Date(Math.max(ev.end - 1, ev.start));
  for (let d = new Date(s.getFullYear(), s.getMonth(), s.getDate()); d <= e && out.length < 62; d.setDate(d.getDate() + 1)) out.push(ymd(d));
  return out;
}
function visibleEvents() {
  const out = []; const linked = new Set(); for (const n of S.notes.values()) if (n.calLink?.remoteId) linked.add(n.calLink.remoteId);
  for (const ev of CAL.events.values()) {
    const a = calAcct(ev.accountId); const c = calOf(a, ev.calendarId); if (!a || !c || !c.show) continue;
    if ((ev.gsId && S.notes.has(ev.gsId)) || linked.has(ev.remoteId)) continue; // MyGSNotes+' own task events are already shown as tasks
    out.push(ev);
  }
  return out;
}
function eventsByDay() { const m = {}; for (const ev of visibleEvents()) for (const d of evDays(ev)) (m[d] ||= []).push(ev); for (const k in m) m[k].sort((x, y) => (y.allDay - x.allDay) || evStartMs(x) - evStartMs(y)); return m; }
const fmtTime = (ms) => new Date(ms).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
function fmtWhenEvent(ev) {
  if (ev.allDay) { const days = parseDay(ev.end) - parseDay(ev.start); return shortDate(ev.start) + (days > 1 ? ` – ${shortDate(dayToYmd(parseDay(ev.end) - 1))}` : '') + ' · all day'; }
  const s = new Date(ev.start), e = new Date(ev.end);
  return s.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }) + ' · ' + fmtTime(ev.start) + (ev.end > ev.start ? '–' + (ymd(s) === ymd(e) ? fmtTime(ev.end) : e.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + fmtTime(ev.end)) : '');
}
const calColor = (ev) => calOf(calAcct(ev.accountId), ev.calendarId)?.color || 1;
function agendaMarkdown(day) {
  const evs = (eventsByDay()[day] || []);
  if (!evs.length) return calCfg().accounts.length ? '- No events' : '- (Connect a calendar to see your agenda here)';
  return evs.map((ev) => `- ${ev.allDay ? 'All day' : `${fmtTime(Math.max(ev.start, new Date(day + 'T00:00').getTime()))}–${fmtTime(ev.end)}`} **${ev.title.replace(/[*_[\]]/g, '')}**${ev.location ? ' · ' + ev.location : ''}`).join('\n');
}

/* ---------- sync ---------- */
const taskSig = (n) => `${n.title}|${n.due}|${n.done ? 1 : 0}|${stripMd(n.body).slice(0, 200)}`;
async function syncCalendars(manual = false) {
  const cfg = calCfg();
  if (CAL.busy || !cfg.accounts.length) { if (manual && !cfg.accounts.length) toast('Add a calendar account first.'); return; }
  CAL.busy = true; if (S.ui.view === 'calendar') renderView();
  const from = now() - 60 * 864e5, to = now() + 400 * 864e5;
  let errors = 0;
  try {
    for (const a of cfg.accounts) {
      if (a.provider === 'file') continue;
      if (!window.gsDesktop && a.provider !== 'ics') { a.error = 'Open MyGSNotes+ in the desktop app to sync this account.'; continue; }
      try {
        for (const c of a.calendars) {
          const t = cfg.pushTarget; if (!c.show && !(t && t.accountId === a.id && t.calendarId === c.id)) continue;
          const evs = await PROV[a.provider].fetch(a, c, from, to); if (evs) await storeEvents(a, c, evs);
        }
        a.lastSync = now(); a.error = '';
      } catch (e) { a.error = e.message; errors++; }
    }
    const res = await pushTasks();
    cfg.lastSync = now();
    if (manual) toast(errors ? `Synced with ${errors} problem${errors === 1 ? '' : 's'} — see Calendars` : `Calendars synced${res.created + res.updated + res.pulled ? ` · ${res.created} added, ${res.updated} updated, ${res.pulled} changed from calendar` : ''}`, !!errors, 5000);
  } finally { CAL.busy = false; await saveSettings(); if (S.ui.view === 'calendar') renderView(); renderRail(); }
}
async function pushTasks() {
  const cfg = calCfg(); const t = cfg.pushTarget; const res = { created: 0, updated: 0, pulled: 0, removed: 0 };
  const a = t && calAcct(t.accountId); const c = a && calOf(a, t.calendarId);
  if (t && (!a || !c || !window.gsDesktop)) return res;
  for (const n of [...S.notes.values()]) {
    if (n.locked) continue;
    const want = !n.deleted && n.isTodo && /^\d{4}-\d{2}-\d{2}$/.test(n.due || '') && !isVaultFolder(n.folderId) && !n.projectId;
    let L = n.calLink;
    try {
      if (L && (!t || L.accountId !== t.accountId || L.calendarId !== t.calendarId)) { // target changed: take the old event away
        const oa = calAcct(L.accountId); if (oa && window.gsDesktop) { try { await PROV[oa.provider].remove(oa, calOf(oa, L.calendarId) || { id: L.calendarId }, L.remoteId); } catch {} }
        n.calLink = null; await saveNote(n, { snapshot: false, touch: false }); L = null;
      }
      if (!t) continue;
      if (!want) { if (L) { await PROV[a.provider].remove(a, c, L.remoteId); n.calLink = null; await saveNote(n, { snapshot: false, touch: false }); res.removed++; } continue; }
      const remote = L && findRemote(a.id, c.id, L.remoteId);
      if (L && !remote) { if (L.sig === taskSig(n)) { continue; } L = null; } // deleted in the calendar: leave it until the task changes
      if (L && remote) {
        const rDone = /^✓\s*/.test(remote.title); const rTitle = remote.title.replace(/^✓\s*/, ''); const rDue = remote.allDay ? remote.start : ymd(new Date(remote.start));
        const remoteChanged = rDue !== L.pushedDue || rTitle !== L.pushedTitle || rDone !== !!L.pushedDone;
        const localChanged = taskSig(n) !== L.sig;
        if (remoteChanged && (!localChanged || (remote.updated || 0) > n.updatedAt)) {
          Object.assign(n, { due: rDue, title: rTitle, done: rDone, status: rDone ? 'done' : (n.status === 'done' ? 'todo' : n.status) });
          n.calLink = { ...L, pushedDue: rDue, pushedTitle: rTitle, pushedDone: rDone }; n.calLink.sig = taskSig(n);
          await saveNote(n, { snapshot: false }); res.pulled++; continue;
        }
        if (!localChanged) continue;
        await PROV[a.provider].update(a, c, L.remoteId, taskPayload(n));
        n.calLink = { ...L, pushedDue: n.due, pushedTitle: n.title || 'Untitled', pushedDone: !!n.done, sig: taskSig(n) };
        await saveNote(n, { snapshot: false, touch: false }); res.updated++; continue;
      }
      const ev = await PROV[a.provider].create(a, c, taskPayload(n));
      n.calLink = { accountId: a.id, calendarId: c.id, remoteId: ev.remoteId, pushedDue: n.due, pushedTitle: n.title || 'Untitled', pushedDone: !!n.done, sig: taskSig(n) };
      ev.gsId = n.id; ev.occ = ''; ev.accountId = a.id; ev.calendarId = c.id; ev.key = evKey(a.id, c.id, ev); CAL.events.set(ev.key, ev);
      await saveNote(n, { snapshot: false, touch: false }); res.created++;
    } catch (e) { if (a) a.error = e.message; }
  }
  return res;
}
let calTimer = null;
function scheduleCalSync() { clearInterval(calTimer); const m = calCfg().autoSyncMin; if (m > 0) calTimer = setInterval(() => syncCalendars(false), m * 60000); }

/* ---------- UI: accounts ---------- */
const keyringNote = () => CAL.info?.secureStorage === false ? '<b>Your system keyring isn’t available</b>, so the sign-in is saved unencrypted in your MyGSNotes+ profile folder. Installing and unlocking GNOME Keyring or KWallet fixes this.' : 'The sign-in is stored encrypted by your operating system’s keyring.';
const colorDot = (n) => `<i class="cdot-s" style="background:var(--c${n})"></i>`;
function calendarsDialog() {
  const cfg = calCfg(); const desk = !!window.gsDesktop;
  const writable = cfg.accounts.flatMap((a) => a.calendars.filter((c) => c.writable && a.provider !== 'ics' && a.provider !== 'file').map((c) => ({ a, c })));
  const d = openDialog(`${dlgHead('Calendars')}
    <div class="dialog-b" id="cd-body">
      ${cfg.accounts.length ? cfg.accounts.map((a) => `<div class="acct" data-acct="${a.id}">
        <div class="row"><b class="grow">${esc(a.label)}</b><span class="chip">${esc(PROVIDER_LABEL[a.provider])}</span>${a.provider !== 'file' ? `<button class="btn sm" data-ca="sync">Sync</button>` : ''}<button class="btn sm danger" data-ca="remove">Remove</button></div>
        ${a.email && a.email !== a.label ? `<span class="small muted">${esc(a.email)}</span>` : ''}
        ${a.error ? `<p class="small" style="margin:0;color:var(--bad)">${esc(a.error)}</p>` : a.lastSync ? `<span class="small muted">Synced ${esc(fmtWhen(a.lastSync))}</span>` : ''}
        <div class="cal-list">${a.calendars.map((c) => `<label class="row small"><input type="checkbox" data-show="${esc(c.id)}"${c.show ? ' checked' : ''}><button type="button" class="cdot" style="--oc:var(--c${c.color})" data-color="${esc(c.id)}" title="Change color" aria-label="Change color of ${esc(c.name)}"></button>${esc(c.name)}${c.writable ? '' : ' <span class="muted">(read-only)</span>'}</label>`).join('')}</div>
      </div>`).join('') : '<p class="muted" style="margin:0">No calendars connected yet.</p>'}
      <h4 style="margin:6px 0 0">Add a calendar</h4>
      <div class="imp-grid">
        <button class="imp" data-add="google"${desk ? '' : ' disabled'}><b>Google Calendar</b><span class="small muted">Gmail and Google Workspace. Two-way.</span></button>
        <button class="imp" data-add="microsoft"${desk ? '' : ' disabled'}><b>Outlook.com / Hotmail / Microsoft 365</b><span class="small muted">Personal and work accounts. Two-way.</span></button>
        <button class="imp" data-add="caldav"${desk ? '' : ' disabled'}><b>iCloud, Fastmail, Nextcloud, Yahoo…</b><span class="small muted">Any CalDAV server with an app password. Two-way.</span></button>
        <button class="imp" data-add="ics"><b>Subscribe by link</b><span class="small muted">Any calendar’s .ics / iCal address. Read-only.</span></button>
        <button class="imp" data-add="file"><b>Import an .ics file</b><span class="small muted">A one-time copy of events from a file.</span></button>
      </div>
      ${desk ? '' : '<p class="small muted" style="margin:0">Google, Microsoft and CalDAV accounts need the MyGSNotes+ desktop app, because those services don’t let a web page sign in this way. Links work here only if the server allows browser access.</p>'}
      <h4 style="margin:6px 0 0">Tasks in your calendar</h4>
      <label class="field">Put my tasks that have a due date on<select class="select" id="cd-push"><option value="">— Don’t add tasks to a calendar —</option>${writable.map(({ a, c }) => `<option value="${a.id}|${esc(c.id)}"${cfg.pushTarget?.accountId === a.id && cfg.pushTarget?.calendarId === c.id ? ' selected' : ''}>${esc(a.label)} — ${esc(c.name)}</option>`).join('')}</select></label>
      <p class="small muted" style="margin:0">Each task becomes an all-day event. Move the event or rename it in your calendar and the task follows; mark it done by adding ✓ to the start of its title. Vault notes and project items are never sent.</p>
      <div class="grid2"><label class="field">Sync automatically<select class="select" id="cd-auto">${[[0, 'Only when I click Sync'], [5, 'Every 5 minutes'], [15, 'Every 15 minutes'], [60, 'Every hour']].map(([v, l]) => `<option value="${v}"${(cfg.autoSyncMin ?? 15) === v ? ' selected' : ''}>${l}</option>`).join('')}</select></label>
        <div class="field"><span>&nbsp;</span><button class="btn" id="cd-export" type="button">Export tasks as .ics</button></div></div>
    </div>
    <div class="dialog-f"><button class="btn" data-close>Close</button><button class="btn primary" id="cd-syncall">Sync now</button></div>`, { wide: true });
  const reopen = () => { d.close(); calendarsDialog(); };
  d.el.addEventListener('change', async (e) => {
    const t = e.target; const a = calAcct(t.closest('[data-acct]')?.dataset.acct);
    if (t.dataset.show && a) { calOf(a, t.dataset.show).show = t.checked; await saveSettings(); if (t.checked) syncCalendars(false); if (S.ui.view === 'calendar') renderView(); }
    if (t.id === 'cd-push') { const [accountId, ...rest] = t.value.split('|'); cfg.pushTarget = t.value ? { accountId, calendarId: rest.join('|') } : null; await saveSettings(); toast(t.value ? 'Tasks will be added on the next sync' : 'Tasks will be taken off the calendar on the next sync'); syncCalendars(false); }
    if (t.id === 'cd-auto') { cfg.autoSyncMin = +t.value; await saveSettings(); scheduleCalSync(); }
  });
  d.el.addEventListener('click', async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    const a = calAcct(b.closest('[data-acct]')?.dataset.acct);
    if (b.dataset.color && a) { const c = calOf(a, b.dataset.color); c.color = (c.color % 8) + 1; b.style.setProperty('--oc', `var(--c${c.color})`); await saveSettings(); if (S.ui.view === 'calendar') renderView(); return; }
    if (b.dataset.ca === 'sync' && a) { await syncCalendars(true); return reopen(); }
    if (b.dataset.ca === 'remove' && a) { d.close(); return confirmDialog(`Remove ${a.label}?`, 'Its events disappear from MyGSNotes+. Nothing is deleted from the calendar itself, except task events MyGSNotes+ added, which are removed if this was your task calendar.', 'Remove', () => removeCalAccount(a)); }
    if (b.dataset.add) { d.close(); return ({ google: () => oauthDialog('google'), microsoft: () => oauthDialog('microsoft'), caldav: caldavDialog, ics: icsLinkDialog, file: importIcsFile })[b.dataset.add](); }
    if (b.id === 'cd-syncall') { await syncCalendars(true); return reopen(); }
    if (b.id === 'cd-export') return exportTasksIcs();
  });
}
async function addCalAccount(a) {
  a.calendars = (await PROV[a.provider].list(a)).map((c, i) => ({ ...c, show: a.provider !== 'google' || c.primary || i < 3, color: ((calCfg().accounts.reduce((n, x) => n + x.calendars.length, 0) + i) % 8) + 1 }));
  calCfg().accounts.push(a); await saveSettings();
  await syncCalendars(false); toast(`Connected ${a.label}`); go('calendar');
}
async function removeCalAccount(a) {
  const cfg = calCfg();
  if (cfg.pushTarget?.accountId === a.id && window.gsDesktop) { for (const n of S.notes.values()) if (n.calLink?.accountId === a.id) { try { await PROV[a.provider].remove(a, calOf(a, n.calLink.calendarId) || { id: n.calLink.calendarId }, n.calLink.remoteId); } catch {} } }
  for (const n of S.notes.values()) if (n.calLink?.accountId === a.id) { n.calLink = null; await saveNote(n, { snapshot: false, touch: false }); }
  if (cfg.pushTarget?.accountId === a.id) cfg.pushTarget = null;
  for (const c of a.calendars) await DB.del('events', `${a.id}|${c.id}`);
  for (const k of [...CAL.events.keys()]) if (k.startsWith(a.id + '|')) CAL.events.delete(k);
  if (a.credId && window.gsDesktop?.calForget) await window.gsDesktop.calForget(a.credId);
  cfg.accounts = cfg.accounts.filter((x) => x.id !== a.id); await saveSettings();
  toast(`Removed ${a.label}`); if (S.ui.view === 'calendar') renderView();
}
function oauthDialog(provider) {
  const cfg = calCfg(); const g = provider === 'google';
  const guide = g ? `<ol class="small guide">
      <li>Open <b>console.cloud.google.com</b> and create a project (any name).</li>
      <li><b>APIs &amp; Services → Library</b>: enable <b>Google Calendar API</b>.</li>
      <li><b>OAuth consent screen</b>: choose <b>External</b> (or Internal for a Workspace domain) and add your Gmail address as a <b>test user</b>.</li>
      <li><b>Credentials → Create credentials → OAuth client ID</b>, type <b>Desktop app</b>. Copy the Client ID and Client secret here.</li>
      <li>Google expires sign-ins after 7 days while the app’s publishing status is <b>Testing</b>. Set it to <b>In production</b> to avoid that; Google then shows an “unverified app” notice you can continue past.</li></ol>`
    : `<ol class="small guide">
      <li>Open <b>entra.microsoft.com</b> (or portal.azure.com) → <b>App registrations → New registration</b>.</li>
      <li>Supported account types: <b>Accounts in any organizational directory and personal Microsoft accounts</b>. This covers Hotmail and Outlook.com as well as work accounts.</li>
      <li>Redirect URI: platform <b>Public client/native (mobile &amp; desktop)</b>, value <code>http://localhost</code>.</li>
      <li><b>API permissions</b>: Microsoft Graph, delegated <b>Calendars.ReadWrite</b>, <b>User.Read</b> and <b>offline_access</b>.</li>
      <li>Copy the <b>Application (client) ID</b> here. No secret is needed.</li></ol>`;
  const d = openDialog(`${dlgHead(g ? 'Connect Google Calendar' : 'Connect Outlook.com / Hotmail / Microsoft 365')}
    <form class="dialog-b" id="oa-form">
      <p class="small" style="margin:0">MyGSNotes+ signs in through your browser, so your password never passes through MyGSNotes+. ${keyringNote()}</p>
      <p class="small" style="margin:0">${g ? 'Google' : 'Microsoft'} requires every app to be registered. Because MyGSNotes+ runs only on your computer, you register it once under your own account (about 5 minutes):</p>
      <details${(g ? cfg.googleClientId : cfg.msClientId) ? '' : ' open'}><summary class="small">How to get a Client ID</summary>${guide}</details>
      <label class="field">Client ID<input class="input" id="oa-id" value="${esc(g ? cfg.googleClientId : cfg.msClientId)}" required autocomplete="off"></label>
      ${g ? `<label class="field">Client secret<input class="input" id="oa-secret" type="password" value="${esc(cfg.googleClientSecret)}" autocomplete="off"></label>` : ''}
      <p class="small" id="oa-msg" style="margin:0"></p>
    </form><div class="dialog-f"><button class="btn" data-close>Cancel</button><button class="btn primary" form="oa-form" id="oa-go">Sign in with ${g ? 'Google' : 'Microsoft'}</button></div>`, { wide: true });
  $('#oa-form', d.el).onsubmit = async (e) => {
    e.preventDefault();
    const clientId = $('#oa-id', d.el).value.trim(); const clientSecret = $('#oa-secret', d.el)?.value.trim() || '';
    if (g) { cfg.googleClientId = clientId; cfg.googleClientSecret = clientSecret; } else cfg.msClientId = clientId; await saveSettings();
    $('#oa-go', d.el).disabled = true; $('#oa-msg', d.el).textContent = 'Finish signing in in your browser, then come back here…';
    const r = await window.gsDesktop.calOAuth({ provider, clientId, clientSecret });
    if (r.error) { $('#oa-msg', d.el).innerHTML = `<span style="color:var(--bad)">${esc(r.error)}</span>`; $('#oa-go', d.el).disabled = false; return; }
    $('#oa-msg', d.el).textContent = 'Signed in. Loading your calendars…';
    try { await addCalAccount({ id: uid(), provider, credId: r.accountId, email: r.email, label: r.email || (g ? 'Google' : 'Microsoft'), calendars: [] }); d.close(); }
    catch (err) { await window.gsDesktop.calForget(r.accountId); $('#oa-msg', d.el).innerHTML = `<span style="color:var(--bad)">${esc(err.message)}</span>`; $('#oa-go', d.el).disabled = false; }
  };
}
const CALDAV_PRESETS = [['icloud', 'iCloud', 'https://caldav.icloud.com/', 'Use your Apple ID email and an app-specific password from appleid.apple.com → Sign-In and Security → App-Specific Passwords.'], ['fastmail', 'Fastmail', 'https://caldav.fastmail.com/dav/', 'Use your Fastmail address and an app password from Settings → Privacy & Security → App passwords.'], ['yahoo', 'Yahoo', 'https://caldav.calendar.yahoo.com/', 'Use your Yahoo address and an app password from Account security → Generate app password.'], ['nextcloud', 'Nextcloud / ownCloud', 'https://YOUR-SERVER/remote.php/dav/', 'Replace YOUR-SERVER. Use an app password from Settings → Security → Devices & sessions.'], ['other', 'Other CalDAV server', '', 'Enter the server’s CalDAV address and your username and password.']];
function caldavDialog() {
  const d = openDialog(`${dlgHead('Connect a CalDAV calendar')}
    <form class="dialog-b" id="cv-form">
      <label class="field">Service<select class="select" id="cv-preset">${CALDAV_PRESETS.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label>
      <p class="small muted" id="cv-hint" style="margin:0"></p>
      <label class="field">Server address<input class="input" id="cv-url" required></label>
      <div class="grid2"><label class="field">Username / email<input class="input" id="cv-user" required autocomplete="off"></label><label class="field">App password<input class="input" id="cv-pass" type="password" required autocomplete="off"></label></div>
      <p class="small muted" style="margin:0">${keyringNote()}</p>
      <p class="small" id="cv-msg" style="margin:0"></p>
    </form><div class="dialog-f"><button class="btn" data-close>Cancel</button><button class="btn primary" form="cv-form" id="cv-go">Connect</button></div>`);
  const sync = () => { const p = CALDAV_PRESETS.find((x) => x[0] === $('#cv-preset', d.el).value); $('#cv-url', d.el).value = p[2]; $('#cv-hint', d.el).textContent = p[3]; };
  $('#cv-preset', d.el).onchange = sync; sync();
  $('#cv-form', d.el).onsubmit = async (e) => {
    e.preventDefault(); $('#cv-go', d.el).disabled = true; $('#cv-msg', d.el).textContent = 'Connecting…';
    const preset = CALDAV_PRESETS.find((x) => x[0] === $('#cv-preset', d.el).value);
    const r = await window.gsDesktop.calBasic({ username: $('#cv-user', d.el).value.trim(), password: $('#cv-pass', d.el).value });
    const a = { id: uid(), provider: 'caldav', credId: r.accountId, url: $('#cv-url', d.el).value.trim(), email: $('#cv-user', d.el).value.trim(), label: `${preset[1].split(' ')[0]} — ${$('#cv-user', d.el).value.trim()}`, calendars: [] };
    try { await addCalAccount(a); d.close(); }
    catch (err) { await window.gsDesktop.calForget(r.accountId); $('#cv-msg', d.el).innerHTML = `<span style="color:var(--bad)">${esc(err.message)}</span>`; $('#cv-go', d.el).disabled = false; }
  };
}
function icsLinkDialog() {
  const d = openDialog(`${dlgHead('Subscribe to a calendar link')}
    <form class="dialog-b" id="il-form">
      <label class="field">Calendar link (.ics, iCal or webcal)<input class="input" id="il-url" required placeholder="https://… or webcal://…"></label>
      <label class="field">Name<input class="input" id="il-name" placeholder="e.g. Work calendar"></label>
      <details><summary class="small">Where to find the link</summary><ul class="small guide">
        <li><b>Google Calendar</b>: Settings → your calendar → Integrate calendar → <b>Secret address in iCal format</b>.</li>
        <li><b>Outlook.com / Hotmail</b>: Settings → Calendar → Shared calendars → <b>Publish a calendar</b> → copy the <b>ICS</b> link.</li>
        <li><b>Microsoft 365</b>: the same Publish option, if your organization allows it.</li>
        <li><b>iCloud</b>: share the calendar as a Public Calendar and copy its link.</li>
        <li>Holiday, sports and school calendars usually offer an iCal link too.</li></ul>
        <p class="small muted">Treat a secret link like a password: anyone who has it can read that calendar.</p></details>
      <p class="small" id="il-msg" style="margin:0"></p>
    </form><div class="dialog-f"><button class="btn" data-close>Cancel</button><button class="btn primary" form="il-form" id="il-go">Subscribe</button></div>`);
  $('#il-form', d.el).onsubmit = async (e) => {
    e.preventDefault(); const url = $('#il-url', d.el).value.trim();
    let host = 'Calendar'; try { host = new URL(url.replace(/^webcal:/i, 'https:')).hostname.replace(/^www\./, ''); } catch {}
    const a = { id: uid(), provider: 'ics', url, label: $('#il-name', d.el).value.trim() || host, calendars: [] };
    $('#il-go', d.el).disabled = true; $('#il-msg', d.el).textContent = 'Reading the calendar…';
    try { await PROV.ics.fetch(a, null, now() - 864e5, now() + 864e5); await addCalAccount(a); d.close(); }
    catch (err) { $('#il-msg', d.el).innerHTML = `<span style="color:var(--bad)">${esc(err.message)}</span>`; $('#il-go', d.el).disabled = false; }
  };
}
async function importIcsFile(fileArg) {
  const f = fileArg || (await pickFiles('.ics,text/calendar', false))[0]; if (!f) return;
  try {
    const evs = await parseIcs(await f.text(), now() - 5 * 365 * 864e5, now() + 5 * 365 * 864e5);
    const a = { id: uid(), provider: 'file', label: f.name.replace(/\.ics$/i, ''), calendars: [{ id: 'file', name: f.name.replace(/\.ics$/i, ''), show: true, writable: false, color: (calCfg().accounts.length % 8) + 1 }] };
    calCfg().accounts.push(a); await storeEvents(a, a.calendars[0], evs); await saveSettings();
    toast(`Imported ${evs.length} event${evs.length === 1 ? '' : 's'} from ${f.name}`); go('calendar');
  } catch (e) { toast(e.message, true, 6000); }
}
async function exportTasksIcs() {
  const tasks = liveNotes().filter((n) => !n.locked && n.isTodo && /^\d{4}-\d{2}-\d{2}$/.test(n.due || '') && !isVaultFolder(n.folderId));
  if (!tasks.length) return toast('No tasks have due dates yet.');
  const body = tasks.map((n) => icsEvent({ uidv: 'gsnotes-' + n.id, ...taskPayload(n) })).join('\r\n');
  const ok = await download(`gsnotes-tasks-${ymd()}.ics`, icsWrap(body, 'MyGSNotes+ tasks'), 'text/calendar');
  if (ok !== false) toast(`Exported ${tasks.length} task${tasks.length === 1 ? '' : 's'}. Import the file into any calendar app.`);
}

/* ---------- UI: event details & meeting notes ---------- */
function eventDialog(ev) {
  const a = calAcct(ev.accountId); const c = calOf(a, ev.calendarId);
  const ref = ev.key.split('|').slice(0, 4).join('|');
  const linked = [...S.notes.values()].find((n) => !n.deleted && n.eventRef?.ref === ref && n.eventRef?.start === ev.start);
  const d = openDialog(`${dlgHead(esc(ev.title))}
    <div class="dialog-b">
      <div class="row small">${colorDot(c?.color || 1)}<span>${esc(c?.name || '')}${a && a.label !== c?.name ? ' · ' + esc(a.label) : ''}</span>${ev.recurring ? '<span class="chip">repeats</span>' : ''}</div>
      <p style="margin:0"><b>${esc(fmtWhenEvent(ev))}</b></p>
      ${ev.location ? `<p class="small" style="margin:0">📍 ${esc(ev.location)}</p>` : ''}
      ${ev.meet ? `<p class="small" style="margin:0"><a href="${esc(ev.meet)}" target="_blank" rel="noopener noreferrer">Join the online meeting</a></p>` : ''}
      ${ev.attendees?.length ? `<div class="small"><b>Attendees (${ev.attendees.length})</b><div class="att-list">${ev.attendees.slice(0, 40).map((p) => `<span class="chip">${esc(p.name || p.email)}${p.status && /accept/.test(p.status) ? ' ✓' : /decline/.test(p.status || '') ? ' ✕' : ''}</span>`).join(' ')}</div></div>` : ''}
      ${ev.description ? `<div class="ev-desc small">${esc(ev.description.slice(0, 2000))}</div>` : ''}
    </div>
    <div class="dialog-f">${ev.url ? `<a class="btn" href="${esc(ev.url)}" target="_blank" rel="noopener noreferrer">Open in ${esc(PROVIDER_LABEL[a?.provider] === 'Google' ? 'Google Calendar' : a?.provider === 'microsoft' ? 'Outlook' : 'calendar')}</a>` : ''}
      <button class="btn primary" id="ev-note">${linked ? 'Open meeting note' : 'Create meeting note'}</button></div>`);
  $('#ev-note', d.el).onclick = async () => { d.close(); if (linked) return openNote(linked.id); const n = await createMeetingNote(ev, ref); openNote(n.id); };
}
async function createMeetingNote(ev, ref) {
  const when = fmtWhenEvent(ev); const day = ev.allDay ? ev.start : ymd(new Date(ev.start));
  const people = (ev.attendees || []).map((p) => p.name || p.email).filter(Boolean).join(', ');
  const tpl = liveNotes().find((x) => x.folderId === S.settings.templateFolder && /meeting/i.test(x.title));
  let body = tpl ? fillTemplate(tpl.body, ev.title) : `## Agenda\n\n## Notes\n\n## Action items\n- [ ] \n`;
  body = body.replace(/^\*\*Date:\*\*.*$/m, '').replace(/^\*\*Attendees:\*\*.*$/m, '').replace(/^\s+/, '');
  const head = [`**When:** ${when}`, ev.location ? `**Where:** ${ev.location}` : '', ev.meet ? `**Join:** ${ev.meet}` : '', people ? `**Attendees:** ${people}` : ''].filter(Boolean).join('  \n');
  const meetings = await ensureFolderPath(['Meetings']);
  const n = newNote({ folderId: meetings, title: `${ev.title} — ${day}`, tags: ['meeting'], body: (head ? head + '\n\n' : '') + body, eventRef: { ref, start: ev.start, title: ev.title } });
  await saveNote(n, { snapshot: false });
  return n;
}

function dayListDialog(day) {
  const xs = eventsByDay()[day] || []; const tasks = liveNotes().filter((n) => !n.locked && n.isTodo && n.due === day);
  const d = openDialog(`${dlgHead(esc(new Date(day + 'T12:00').toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })))}
    <div class="dialog-b">${xs.map((e) => `<button class="day-row" data-cev="${esc(e.key)}">${colorDot(calColor(e))}<span class="mono small">${e.allDay ? 'All day' : esc(fmtTime(e.start))}</span><b>${esc(e.title)}</b></button>`).join('')}
    ${tasks.map((n) => `<button class="day-row" data-open="${n.id}"><span>${n.done ? '☑' : '☐'}</span><span class="mono small">Task</span><b>${esc(n.title || 'Untitled')}</b></button>`).join('') || (xs.length ? '' : '<p class="muted">Nothing on this day.</p>')}</div>`);
  d.el.addEventListener('click', (e) => { const c = e.target.closest('[data-cev]'); if (c) { d.close(); eventDialog(CAL.events.get(c.dataset.cev)); } const o = e.target.closest('[data-open]'); if (o) { d.close(); openNote(o.dataset.open); } });
}
async function initCalendars() {
  if (window.gsDesktop?.calInfo) { try { CAL.info = await window.gsDesktop.calInfo(); CAL.bases = CAL.info.bases; } catch {} }
  await loadEvents(); scheduleCalSync();
  if (calCfg().accounts.length) setTimeout(() => syncCalendars(false), 4000);
}
